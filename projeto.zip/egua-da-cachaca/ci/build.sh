#!/bin/bash
# Compila o APK. Roda dentro do GitHub Actions (veja .github/workflows/apk.yml).
# Fica aqui dentro do projeto.zip para que mudanças no processo de build não exijam mexer no workflow.
set -euo pipefail

echo "::group::Instalar dependências"
npm install
echo "::endgroup::"

echo "::group::Criar o projeto Android"
npx cap add android
echo "::endgroup::"

echo "Aplicar ícones e assinatura"
cp -r android-res/. android/app/src/main/res/
mkdir -p ~/.android
cp ci/debug.keystore ~/.android/debug.keystore
# Assinatura FIXA: sem isso o Android recusa instalar um APK novo por cima do antigo ("conflito de pacote").
cp ci/debug.keystore android/app/egua-debug.keystore
cat >> android/app/build.gradle <<'GRADLE'

android {
    signingConfigs {
        debug {
            storeFile file('egua-debug.keystore')
            storePassword 'android'
            keyAlias 'androiddebugkey'
            keyPassword 'android'
        }
    }
}
GRADLE
# versionCode sobe a cada build (o Android só aceita instalar igual ou maior)
sed -i "s/versionCode 1$/versionCode ${GITHUB_RUN_NUMBER:-1}/" android/app/build.gradle
grep -n "versionCode\|egua-debug" android/app/build.gradle

echo "Numerar a versão do app"
echo "{\"v\": ${GITHUB_RUN_NUMBER:-1}, \"api\": 1}" > public/version.json

echo "Colocar o servidor da adega dentro do app"
PKG=android/app/src/main/java/br/com/eguadacachaca/app
mkdir -p "$PKG"
cp android-java/*.java "$PKG/"
MF=android/app/src/main/AndroidManifest.xml
grep -q usesCleartextTraffic "$MF" || sed -i 's/<application/<application android:usesCleartextTraffic="true"/' "$MF"
grep -q "android.permission.CAMERA" "$MF" || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application#' "$MF"
python3 ci/patch_manifest.py "$MF"

echo "Copiar o app para o Android"
npx cap sync android

echo "Aceitar licenças do Android SDK"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true

echo "Compilar o APK"
(cd android && ./gradlew assembleDebug --no-daemon)

echo "Conferir a assinatura do APK"
EXPECT=$(keytool -exportcert -alias androiddebugkey -keystore ci/debug.keystore -storepass android | sha256sum | cut -d' ' -f1)
APKSIGNER="$(ls -d "$ANDROID_HOME"/build-tools/*/apksigner 2>/dev/null | sort -V | tail -1 || true)"
APKSIGN=""
if [ -n "$APKSIGNER" ]; then APKSIGN="$("$APKSIGNER" verify --print-certs android/app/build/outputs/apk/debug/app-debug.apk 2>&1 | grep -i 'SHA-256' | head -1 | sed 's/.*: //' || true)"; fi
echo "esperado: $EXPECT"; echo "no APK:  $APKSIGN"
if [ -n "$APKSIGN" ] && [ "$APKSIGN" != "$EXPECT" ]; then echo "ERRO: o APK não foi assinado com a chave fixa"; exit 1; fi

echo "Publicar o APK em Releases"
cp android/app/build/outputs/apk/debug/app-debug.apk egua-da-cachaca.apk
gh release delete apk-atual --yes --cleanup-tag 2>/dev/null || true
(cd public && zip -qr ../www.zip .)
cp public/version.json version.json
gh release create apk-atual egua-da-cachaca.apk www.zip version.json --target "$GITHUB_SHA" \
  --title "APK mais recente" \
  --notes "Baixe o arquivo egua-da-cachaca.apk no celular Android e instale."
