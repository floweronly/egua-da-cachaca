#!/usr/bin/env python3
"""Acrescenta ao AndroidManifest.xml gerado: permissões, o serviço do servidor e o início após reiniciar."""
import re, sys

path = sys.argv[1]
s = open(path, encoding='utf-8').read()

perms = [
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.WAKE_LOCK',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
    'android.permission.ACCESS_WIFI_STATE',
]
add = ''.join('    <uses-permission android:name="%s" />\n' % p for p in perms if p not in s)
if add:
    m = re.search(r'<application', s)
    if not m:
        sys.exit('manifest sem <application>')
    s = s[:m.start()] + add.lstrip() + '    ' + s[m.start():]

comp = '''
        <service
            android:name="br.com.eguadacachaca.app.EguaService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Servidor local da adega na rede Wi-Fi" />
        </service>

        <receiver
            android:name="br.com.eguadacachaca.app.BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
'''
if 'br.com.eguadacachaca.app.EguaService' not in s:
    i = s.rfind('</application>')
    if i < 0:
        sys.exit('manifest sem </application>')
    s = s[:i] + comp.lstrip('\n') + '    ' + s[i:]

open(path, 'w', encoding='utf-8').write(s)
print(s)
