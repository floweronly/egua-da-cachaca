# Égua da Cachaça

Estoque, venda e comanda para a adega. **Sem Firebase, sem internet, sem servidor de terceiros.**

## Como funciona

O celular onde o app está instalado (o do Mateus) **é o servidor**. Todos os dados ficam guardados nele.
Nos Ajustes, "Conectar Dispositivos Extras" mostra um **QR code**. Quem escanear com a câmera
(Android ou iPhone) abre uma página do app direto desse celular, pelo **mesmo Wi-Fi**. Não instala nada.

- O celular da adega precisa estar com o app **aberto** (a tela fica ligada de propósito).
- Os outros precisam estar no **mesmo Wi-Fi**. Sem Wi-Fi, ligue o roteador portátil (hotspot) no celular da adega e conecte os outros nele.
- Convite vale 24 horas. "Gerar novo convite" invalida o QR antigo. "Remover" tira um celular na hora.
- Atendente não vê custo nem lucro nem a aba Caixa. (A tela esconde; a rede é local e de confiança.)
- Se o Wi-Fi mudar, o IP muda: abra o QR de novo para os convites novos.

## Gerar o APK (sem instalar nada no PC)

1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta**.
2. Aba **Actions** > "Gerar APK" > Run workflow (também roda sozinho a cada envio).
3. Em ~10 minutos aparece em **Releases** o arquivo `egua-da-cachaca.apk`. Baixe e instale no celular da adega.

O workflow cria o projeto Android (Capacitor), coloca o servidor (`android-java/`) dentro do app e compila.

## Versão só HTML

`egua-da-cachaca.html` funciona sozinho em qualquer navegador/gerador de app, mas **sem servidor**:
os dados ficam só naquele aparelho e o QR de dispositivos extras não funciona. Para vários celulares, use o APK.

## Fotos dos produtos

Em Estoque, abra um produto (ou + Produto) e use **Tirar foto** ou **Escolher da galeria**. A foto aparece ao lado do produto nas listas
(Venda, Estoque, comandas, carrinho) e toque nela para ampliar. Só o administrador coloca foto; todos os celulares conectados veem.
As fotos ficam no celular servidor e são reduzidas automaticamente. Elas **não entram** no "Copiar backup" na versão com servidor.

## Backup

Ajustes > Backup > "Copiar backup". Guarde o texto (ex.: mande para você no WhatsApp). Para trazer de volta: "Restaurar backup".
Se desinstalar o app, os dados somem: faça backup antes.

## Pastas

- `public/`: o app (HTML/CSS/JS). `public/app.js` tem as regras; o mesmo código roda em todos os celulares.
- `android-java/`: `EguaServer.java` (servidor HTTP em Java puro) e `MainActivity.java`.
- `.github/workflows/apk.yml`: receita que gera o APK.

## Chat da ADEGA
Botão de conversa no topo (ao lado da sua letra). Funciona offline, por regras, e usa as mesmas operações do app (sincroniza com os outros celulares). Exemplos: "Adiciona 20 Heineken ao estoque", "Novo produto", "Vendi 2 cachaça no Pix", "Abre a comanda Mesa 3", "Coloca 2 Heineken na mesa 3", "Fecha a mesa 3 no Pix", "Quanto tem de vinho?", "O que está acabando?". Estoque e preços só o administrador altera.

## Atualizar o app sem reinstalar o APK

Depois do primeiro APK instalado, mudanças nas telas e regras (HTML/CSS/JS, pasta `public/`) chegam sozinhas:

1. Você muda os arquivos no GitHub (pelo site ou app do GitHub, no celular mesmo). O "Gerar APK" roda sozinho.
2. No tablet (servidor): Ajustes > Atualização do app > digite `seu-usuario/nome-do-repositorio` (o repositório precisa ser **público**) > Salvar endereço. Só na primeira vez.
3. Sempre que o tablet abrir com internet, ele procura versão nova e mostra "Atualização disponível". Toque em **Atualizar agora**. O app reabre e os outros celulares recarregam sozinhos. Os dados não mudam.

Só mudou o Java (`android-java/`)? Aí precisa instalar um APK novo: aumente o `"api"` no workflow e em `EguaUpdater.java` (`API`).

## Servidor em tempo integral

O servidor da adega roda como serviço em segundo plano, com uma notificação fixa ("Servidor da adega ligado"). Fica no ar com o app fechado e a tela apagada, e sobe sozinho quando o tablet reinicia.

- No primeiro uso, permita as **notificações** e escolha **Permitir** quando o Android perguntar sobre economia de bateria.
- Se ele perguntar e você negou: Configurações > Apps > Égua da Cachaça > Bateria > **Sem restrições**.
- Deixe o tablet ligado, carregando e no Wi-Fi. Não use "Forçar parada" no app.
- Essa mudança é no Java (`android-java/`), então exige instalar um APK novo uma vez.

O passo a passo da compilação fica em `ci/build.sh`; o `apk.yml` do GitHub só abre o projeto.zip e chama esse script.
