/* =====================================================================
   ADEGA — assistente de conversa (offline, por regras)
   Entende frases em português e usa as MESMAS operações do app
   (product.save, sale.create, com.new, com.add...), então tudo
   sincroniza com os outros celulares e respeita as permissões.
   ===================================================================== */
(function(){
'use strict';
var E = window.EguaApp; if (!E) return;
var PAYS = ['Dinheiro', 'Pix', 'Débito', 'Crédito'];
var STOP = {}; 'de do da dos das o a os as ao aos na no nas nos pra para com um uma uns umas mais produto produtos item itens estoque unidade unidades un und unid unids x e que em por favor pf la ai'.split(' ').forEach(function(w){ STOP[w] = 1; });
var UNITS = { un: 1, und: 1, unid: 1, unids: 1, unidade: 1, unidades: 1, pc: 1, pcs: 1 };
var MEAS = { ml: 1, l: 1, lt: 1, litro: 1, litros: 1, kg: 1, g: 1, mg: 1, cl: 1 };
var WORDNUM = { dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, onze: 11, doze: 12, quinze: 15, vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50, cem: 100, cento: 100, duzia: 12 };

var CH = { msgs: [], pend: null, open: false, started: false };
var $ = function(s){ return document.querySelector(s); };

/* ---------- texto ---------- */
function norm(s){ return String(s).normalize('NFC').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
function esc(s){ return String(s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function fmt(s){ return esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>'); }
function tidy(s){ s = String(s).trim().replace(/[,;.!?]+$/, '').replace(/\s+/g, ' '); return s.charAt(0).toUpperCase() + s.slice(1); }
function stem(w){ return w.length > 3 && /s$/.test(w) ? w.slice(0, -1) : w; }
function toks(s){ return norm(s).split(/[^a-z0-9]+/).filter(function(x){ return x && !STOP[x]; }).map(stem); }
function lev(a, b){
  var m = a.length, n = b.length, d = [], i, j;
  for (i = 0; i <= m; i++) { d[i] = [i]; }
  for (j = 1; j <= n; j++) d[0][j] = j;
  for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[m][n];
}
function tm(t, w){ return t === w || (t.length >= 3 && w.indexOf(t) === 0) || (t.length >= 5 && Math.abs(t.length - w.length) <= 1 && lev(t, w) <= 1); }
function parsePrice(s){
  var x = norm(s).replace(/r\$/g, ''), m = x.match(/\d[\d.,]*/); if (!m) return null;
  var v = m[0].replace(/[.,]+$/, '');
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(v)) v = v.replace(/\./g, '');
  v = Math.round(parseFloat(v.replace(',', '.')) * 100);
  return isFinite(v) ? v : null;
}
function isYes(t){ return /^(sim|s|isso|confirma|confirmo|confirmar|pode|ok|okay|beleza|claro|manda|yes|certo|positivo|com certeza|bora|fechado|cria|criar|crie)\b/.test(t); }
function isNo(t){ return /^(nao|n|nope|nunca|negativo|nem)\b/.test(t); }
function isCancel(t){ return /^(cancela|cancelar|deixa|deixa pra la|esquece|esquece isso|para|chega|desisti|desisto|nao quero)\b/.test(t); }
function isCommand(t){ return /^(adicion|acrescent|vend|abre|abrir|fecha|fechar|quanto|quantos|quantas|coloca|tira|remove|ajuda|cadastra|cria|criar|novo|nova|repoe|repor|registra|mostra|lista|muda|altera)/.test(t); }
function cats(){ var m = {}; E.S().products.forEach(function(p){ if (p.cat) m[p.cat] = 1; }); return Object.keys(m).sort(function(a, b){ return a.localeCompare(b, 'pt-BR'); }); }
function matchCat(raw){
  var n = norm(raw).trim(), s = stem(n), r = null;
  cats().forEach(function(c){ var cn = norm(c); if (!r && (cn === n || stem(cn) === s || (n.length >= 3 && cn.indexOf(n) === 0))) r = c; });
  return r;
}

/* ---------- limpeza da frase ---------- */
var WAKE = /^(?:(?:oi|ola|opa|e ai|fala|hey|ei|bom dia|boa tarde|boa noite)[\s,!.:-]*)?adega\b[\s,!.:-]*/;
function strip(raw){
  var r = String(raw).normalize('NFC'), n = norm(r);
  if (n.length !== r.length) r = n;
  var m = n.match(WAKE), cut = m ? m[0].length : 0;
  r = r.slice(cut); n = n.slice(cut);
  var tr = n.match(/[\s.!?]+$/); if (tr) { r = r.slice(0, r.length - tr[0].length); n = n.slice(0, n.length - tr[0].length); }
  return { r: r, n: n };
}
function rm(X, re){ var m = X.n.match(re); if (!m) return null; X.r = X.r.slice(0, m.index) + ' ' + X.r.slice(m.index + m[0].length); X.n = X.n.slice(0, m.index) + ' ' + X.n.slice(m.index + m[0].length); X.r = X.r.replace(/\s+/g, ' ').trim(); X.n = X.n.replace(/\s+/g, ' ').trim(); return m; }

/* ---------- itens: "2 heineken e 1 cachaça", "Heineken, 20 unidades" ---------- */
function parseSeg(s){
  s = s.replace(/meia d[uú]zia/i, '6');
  var tk = s.replace(/[:!?]+/g, ' ').split(/\s+/).filter(Boolean);
  var nt = tk.map(function(x){ return norm(x).replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, ''); });
  var qty = null, drop = {}, i, m;
  for (i = 0; i < nt.length && qty === null; i++) { m = nt[i].match(/^(\d+)x$|^x(\d+)$/); if (m) { qty = +(m[1] || m[2]); drop[i] = 1; } }
  for (i = 0; i < nt.length && qty === null; i++) if (/^\d+$/.test(nt[i]) && UNITS[nt[i + 1]]) { qty = +nt[i]; drop[i] = 1; drop[i + 1] = 1; }
  for (i = 0; i < nt.length && qty === null; i++) if (WORDNUM[nt[i]]) { qty = WORDNUM[nt[i]]; drop[i] = 1; }
  for (i = 0; i < nt.length && qty === null; i++) if (/^\d+$/.test(nt[i]) && !MEAS[nt[i + 1]]) { qty = +nt[i]; drop[i] = 1; }
  for (i = 0; i < nt.length; i++) if (UNITS[nt[i]]) drop[i] = 1;
  var keep = [], kn = [];
  for (i = 0; i < tk.length; i++) if (!drop[i]) { keep.push(tk[i]); kn.push(nt[i]); }
  while (kn.length && STOP[kn[0]]) { kn.shift(); keep.shift(); }
  while (kn.length && STOP[kn[kn.length - 1]]) { kn.pop(); keep.pop(); }
  return { qty: qty, text: keep.join(' ').replace(/[,;.]+$/, '').trim() };
}
function parseItems(r){
  var segs = r.split(/\s*(?:;|\+|,|\s+e\s+)\s*/i).map(parseSeg).filter(function(x){ return x.text || x.qty !== null; });
  var out = [];
  for (var i = 0; i < segs.length; i++) {
    var a = segs[i], b = segs[i + 1];
    if (b && ((a.text && a.qty === null && !b.text && b.qty !== null) || (a.qty !== null && !a.text && b.text && b.qty === null))) { out.push({ qty: a.qty !== null ? a.qty : b.qty, text: a.text || b.text }); i++; }
    else out.push(a);
  }
  return out;
}

/* ---------- achar produto / comanda ---------- */
function findProds(q){
  var qt = toks(q); if (!qt.length) return { list: [], kind: 'none' };
  var full = [], cat = [], part = [];
  E.S().products.forEach(function(p){
    var nt = toks(p.name), ct = toks(p.cat || ''), m = 0, mc = 0;
    qt.forEach(function(t){ var inN = nt.some(function(w){ return tm(t, w); }); if (inN) m++; if (inN || ct.some(function(w){ return tm(t, w); })) mc++; });
    if (m === qt.length) full.push(p); else if (mc === qt.length) cat.push(p); else if (m > 0) part.push(p);
  });
  var qn = qt.join(' '), ex = full.filter(function(p){ return toks(p.name).join(' ') === qn; });
  if (ex.length === 1) return { list: ex, kind: 'exact' };
  if (full.length) return { list: full, kind: 'full' };
  if (cat.length) return { list: cat, kind: 'cat' };
  return { list: part, kind: part.length ? 'part' : 'none' };
}
function choose(list, raw, t){
  var m = t.match(/^(\d+)\b/); if (m && list[+m[1] - 1]) return list[+m[1] - 1];
  var ord = { primeiro: 0, primeira: 0, segundo: 1, segunda: 1, terceiro: 2, terceira: 2, quarto: 3 };
  if (ord[t.split(' ')[0]] !== undefined && list[ord[t.split(' ')[0]]]) return list[ord[t.split(' ')[0]]];
  var ex = list.filter(function(p){ return norm(p.name) === t; }); if (ex.length === 1) return ex[0];
  var qt = toks(raw); if (!qt.length) return null;
  var f = list.filter(function(p){ var nt = toks(p.name); return qt.every(function(x){ return nt.some(function(w){ return tm(x, w); }); }); });
  return f.length === 1 ? f[0] : null;
}
function findComandas(label){
  var n = norm(label).trim(), cs = E.S().comandas;
  if (!n) return cs.slice();
  var ex = cs.filter(function(c){ return norm(c.name) === n; }); if (ex.length) return ex;
  return cs.filter(function(c){ var cn = norm(c.name); return cn.indexOf(n) > -1 || n.indexOf(cn) > -1; });
}

/* ---------- conversa ---------- */
function say(text, chips){ CH.msgs.push({ who: 'bot', text: text, chips: chips || null }); draw(); }
function ask(text, chips, handler){ CH.pend = { h: handler }; say(text, chips); }
function again(raw, t){ if (isCommand(t)) { route(raw, t); return true; } return false; }
function noAdmin(){ if (E.isAdmin()) return false; say('Só o administrador pode mexer no estoque e nos preços. Eu posso registrar vendas e cuidar das comandas pra você.'); return true; }
function runOps(ops){
  var out = [];
  var p = ops.reduce(function(pr, op){ return pr.then(function(ok){ if (!ok) return false; return E.dispatch(op).then(function(r){ out.push(r); return !!(r && r.ok); }); }); }, Promise.resolve(true));
  return p.then(function(ok){ E.refresh(); return { ok: ok, res: out }; }, function(){ E.refresh(); return { ok: false, res: out, offline: true }; });
}
function fail(r, extra){
  if (r.offline) { say('Sem conexão com a adega. Confira o que ficou registrado antes de repetir.'); return; }
  var last = r.res[r.res.length - 1];
  say((extra ? extra + '\n' : '') + E.errMsg(last && last.err));
}
function pname(p){ return '**' + p.name + '**'; }
function Pnow(id){ var r = null; E.S().products.forEach(function(p){ if (p.id === id) r = p; }); return r; }

/* resolve todos os itens para produtos; pergunta se houver dúvida */
function resolveAll(items, allowNew, done){
  var i = 0;
  (function next(){
    if (i >= items.length) return done(items);
    var it = items[i];
    if (!it.text) return ask('Qual produto?', null, function(raw, t){ if (again(raw, t)) return; it.text = parseSeg(raw).text || raw; next(); });
    var f = findProds(it.text);
    if (f.kind === 'exact' || (f.list.length === 1 && f.kind !== 'part')) { it.p = f.list[0]; i++; return next(); }
    if (f.list.length) {
      var part = f.kind === 'part', chips = f.list.slice(0, 6).map(function(p){ return p.name; });
      if (allowNew && part) chips.push('Criar novo');
      return ask(part ? 'Não achei exatamente “' + it.text + '”. Você quis dizer:\n' + f.list.slice(0, 6).map(function(p, k){ return (k + 1) + ') ' + p.name; }).join('\n')
                      : 'Achei mais de um “' + it.text + '”. Qual deles?\n' + f.list.slice(0, 6).map(function(p, k){ return (k + 1) + ') ' + p.name; }).join('\n'), chips, function pick(raw, t){
        var c = choose(f.list, raw, t);
        if (c) { it.p = c; i++; return next(); }
        if (allowNew && /^(criar|novo|nenhum|outro|nao e nenhum)/.test(t)) return newProd(it, function(){ i++; next(); });
        if (again(raw, t)) return;
        ask('Escolha pelo número ou toque em um botão.', chips, pick);
      });
    }
    if (allowNew) return newProd(it, function(){ i++; next(); });
    say('Não achei “' + it.text + '” no estoque. Nada foi registrado.');
  })();
}

/* produto novo: confirma, pergunta o que falta e cria */
function newProd(it, cb){
  if (noAdmin()) return;
  var d = {}, name = tidy(it.text);
  function askQty(){ ask('Quantas unidades vão pro estoque?', null, function(raw, t){ var q = parseSeg(raw).qty; if (q === null || q < 0) return askQty(); it.qty = q; askCat(); }); }
  function askCat(){
    var cs = cats();
    ask('Qual a categoria de ' + name + '?' + (cs.length ? '\nJá existem: ' + cs.join(', ') + '.' : ''), cs.slice(0, 6), function(raw, t){
      if (again(raw, t)) return;
      var c = matchCat(raw); if (c) { d.cat = c; return askPrice(); }
      var nm = tidy(raw);
      ask('A categoria “' + nm + '” ainda não existe. Criar?', ['Sim', 'Não'], function(r2, t2){
        if (isYes(t2)) { d.cat = nm; return askPrice(); }
        if (isNo(t2)) return askCat();
        if (!again(r2, t2)) askCat();
      });
    });
  }
  function askPrice(){ ask('Qual o preço de venda? (ex: 9,50)', null, function(raw, t){ if (again(raw, t)) return; var v = parsePrice(raw); if (v === null || v <= 0) return askPrice(); d.price = v; askCost(); }); }
  function askCost(){
    ask('E quanto você paga nele (custo)? Pode dizer “pular”.', ['Pular'], function(raw, t){
      if (again(raw, t)) return;
      if (/^(pular|pula|nao sei|depois|n)\b/.test(t)) d.cost = 0; else { var v = parsePrice(raw); if (v === null) return askCost(); d.cost = v; }
      finish();
    });
  }
  function finish(){
    var pid = 'p' + E.uid(), rec = { name: name, cat: d.cat, price: d.price, cost: d.cost, qty: it.qty || 0, min: 3 };
    runOps([{ t: 'product.save', pid: pid, d: rec }]).then(function(r){
      if (!r.ok) return fail(r);
      it.p = Pnow(pid) || { id: pid, name: name }; it.created = true; it.rec = rec; cb();
    });
  }
  ask('Não achei “' + name + '” no estoque. Criar como produto novo?', ['Sim', 'Não'], function(raw, t){
    if (isYes(t)) return it.qty === null || it.qty === undefined ? askQty() : askCat();
    if (isNo(t)) return say('Ok, não criei nada.');
    if (!again(raw, t)) say('Ok, deixei pra lá.');
  });
}

/* ---------- ações ---------- */
function actStockAdd(items){
  if (noAdmin()) return;
  resolveAll(items, true, function(){
    var k = 0;
    (function nextQty(){
      for (; k < items.length; k++) if (items[k].qty === null && !items[k].created) {
        var it = items[k];
        return ask('Quantas unidades de ' + pname(it.p) + ' entraram?', null, function(raw, t){ if (again(raw, t)) return; var q = parseSeg(raw).qty; if (q === null || q <= 0) return nextQty(); it.qty = q; k++; nextQty(); });
      }
      var ops = [], lines = [];
      items.forEach(function(it){
        if (it.created) { lines.push('Criei ' + pname(it.p) + ' (' + it.rec.cat + ', ' + E.money(it.rec.price) + ') com ' + it.qty + ' un.'); return; }
        var p = Pnow(it.p.id) || it.p;
        ops.push({ t: 'product.save', pid: p.id, d: { name: p.name, cat: p.cat, price: p.price, cost: p.cost, qty: p.qty + it.qty, min: p.min } });
      });
      if (!ops.length) return say(lines.join('\n'));
      runOps(ops).then(function(r){
        if (!r.ok) return fail(r);
        items.forEach(function(it){ if (!it.created) { var p = Pnow(it.p.id); lines.push('Adicionei ' + it.qty + ' un de ' + pname(it.p) + '. Agora tem ' + (p ? p.qty : '?') + ' un.'); } });
        say(lines.join('\n'));
      });
    })();
  });
}
function actStockSub(items){
  if (noAdmin()) return;
  resolveAll(items, false, function(){
    var k = 0;
    (function nextQty(){
      for (; k < items.length; k++) if (items[k].qty === null) {
        var it = items[k];
        return ask('Quantas unidades de ' + pname(it.p) + ' tirar?', null, function(raw, t){ if (again(raw, t)) return; var q = parseSeg(raw).qty; if (q === null || q <= 0) return nextQty(); it.qty = q; k++; nextQty(); });
      }
      var none = items.filter(function(it){ return it.p.qty <= 0; });
      if (none.length === items.length) return say(pname(none[0].p) + ' já está zerado, não tem o que tirar.');
      var txt = items.map(function(it){ return 'tirar ' + it.qty + ' un de ' + pname(it.p) + ' (de ' + it.p.qty + ' para ' + Math.max(0, it.p.qty - it.qty) + ')'; }).join('; ');
      confirm('Confirma: ' + txt + '?', function(){
        runOps(items.map(function(it){ var p = Pnow(it.p.id) || it.p; return { t: 'product.save', pid: p.id, d: { name: p.name, cat: p.cat, price: p.price, cost: p.cost, qty: Math.max(0, p.qty - it.qty), min: p.min } }; })).then(function(r){
          if (!r.ok) return fail(r);
          say(items.map(function(it){ var p = Pnow(it.p.id); return 'Pronto. ' + pname(it.p) + ' agora tem ' + (p ? p.qty : '?') + ' un.'; }).join('\n'));
        });
      });
    })();
  });
}
function confirm(text, yes){
  ask(text, ['Sim', 'Não'], function(raw, t){
    if (isYes(t)) return yes();
    if (isNo(t)) return say('Ok, cancelei.');
    if (!again(raw, t)) say('Ok, deixei pra lá.');
  });
}
function askPay(then, text){
  ask(text || 'Qual a forma de pagamento?', PAYS, function pay(raw, t){
    var m = t.match(/dinheiro|pix|debito|credito|cartao/);
    if (m) {
      if (m[0] === 'cartao') return ask('Débito ou crédito?', ['Débito', 'Crédito'], pay);
      return then(m[0] === 'dinheiro' ? 'Dinheiro' : m[0] === 'pix' ? 'Pix' : m[0] === 'debito' ? 'Débito' : 'Crédito');
    }
    if (!again(raw, t)) askPay(then, 'Não entendi. Qual a forma de pagamento?');
  });
}
function detectPay(X){
  var m = rm(X, /\b(?:(?:no|na|em|com|via|pelo|de|a)\s+)?(dinheiro|pix|debito|credito|cartao)\b/);
  if (!m) return null;
  var k = m[1]; return k === 'cartao' ? 'cartao' : k === 'dinheiro' ? 'Dinheiro' : k === 'pix' ? 'Pix' : k === 'debito' ? 'Débito' : 'Crédito';
}
function lineList(items){ return items.map(function(it){ return it.qty + '× ' + it.p.name; }).join(', '); }
function actSale(items, pay){
  resolveAll(items, false, function(){
    items.forEach(function(it){ if (it.qty === null) it.qty = 1; });
    var total = items.reduce(function(s, it){ return s + it.p.price * it.qty; }, 0);
    var go = function(pm){
      confirm('Registrar venda: ' + lineList(items) + ' = **' + E.money(total) + '** no ' + pm + '?', function(){
        runOps([{ t: 'sale.create', sid: 's' + E.uid(), pay: pm, lines: items.map(function(it){ return { pid: it.p.id, q: it.qty }; }) }]).then(function(r){
          if (!r.ok) return fail(r);
          say('Venda registrada: ' + E.money(total) + ' no ' + pm + '.');
        });
      });
    };
    if (pay && pay !== 'cartao') go(pay); else askPay(go, pay === 'cartao' ? 'Débito ou crédito?' : null);
  });
}
function comLabel(X){
  var m = X.n.match(/(?:^|\s)(comanda|mesa)\b\s*(?:(?:do|da|de|dos|das)\s+)?(.*)$/); if (!m) return null;
  var kw = m[1], rest = m[2] || '';
  var start = X.n.length - rest.length, rawRest = X.r.slice(start);
  var idx = X.n.length - m[0].length;
  return { kw: kw, rest: rest, rawRest: rawRest, idx: idx + (m[0].charAt(0) === ' ' ? 1 : 0), label: kw === 'mesa' ? 'mesa ' + rest : rest, name: kw === 'mesa' ? 'Mesa ' + rawRest : tidy(rawRest) };
}
function pickComanda(ref, found, cb, allowNew){
  var cs = ref.rest || ref.kw === 'mesa' ? findComandas(ref.label).concat(ref.kw === 'mesa' ? findComandas(ref.rest).filter(function(c){ return findComandas(ref.label).indexOf(c) < 0; }) : []) : E.S().comandas.slice();
  if (!ref.rest && ref.kw === 'comanda') cs = E.S().comandas.slice();
  if (cs.length === 1) return cb(cs[0]);
  if (cs.length > 1) {
    var chips = cs.slice(0, 6).map(function(c){ return c.name; });
    return ask('Qual comanda?\n' + cs.slice(0, 6).map(function(c, k){ return (k + 1) + ') ' + c.name; }).join('\n'), chips, function pk(raw, t){
      var c = choose(cs.map(function(x){ return { name: x.name, id: x.id, c: x }; }), raw, t);
      if (c) return cb(c.c);
      if (!again(raw, t)) ask('Escolha pelo número ou toque em um botão.', chips, pk);
    });
  }
  if (!allowNew || !ref.rest) { say(ref.rest ? 'Não achei a comanda “' + ref.name + '”.' : 'Não tem nenhuma comanda aberta.'); return; }
  confirm('Não achei a comanda “' + ref.name + '”. Abrir uma nova com esse nome?', function(){
    var cid = 'c' + E.uid();
    runOps([{ t: 'com.new', cid: cid, name: ref.name }]).then(function(r){
      if (!r.ok) return fail(r);
      var c = null; E.S().comandas.forEach(function(x){ if (x.id === cid) c = x; });
      cb(c || { id: cid, name: ref.name, items: [], isNew: true }, true);
    });
  });
}
function actComAdd(items, ref){
  pickComanda(ref, null, function(c, justOpened){
    resolveAll(items, false, function(){
      items.forEach(function(it){ if (it.qty === null) it.qty = 1; });
      var ops = [];
      items.forEach(function(it){ for (var k = 0; k < it.qty; k++) ops.push({ t: 'com.add', cid: c.id, pid: it.p.id }); });
      if (ops.length > 120) return say('Quantidade grande demais de uma vez. Tente menos itens.');
      runOps(ops).then(function(r){
        if (!r.ok) {
          var n = r.res.filter(function(x){ return x && x.ok; }).length;
          return fail(r, n ? 'Consegui adicionar ' + n + ' un antes de parar.' : '');
        }
        var cc = null; E.S().comandas.forEach(function(x){ if (x.id === c.id) cc = x; });
        var tot = cc ? cc.items.reduce(function(s, i){ return s + i.price * i.q; }, 0) : 0;
        say((justOpened ? 'Abri a comanda **' + c.name + '** e coloquei ' : 'Coloquei ') + lineList(items) + (justOpened ? '.' : ' na comanda **' + c.name + '**.') + (cc ? ' Total: ' + E.money(tot) + '.' : ''));
      });
    });
  }, true);
}
function actComRemove(items, ref){
  pickComanda(ref, null, function(c){
    resolveAll(items, false, function(){
      var ops = [], lines = [];
      items.forEach(function(it){
        var line = null; c.items.forEach(function(x){ if (x.pid === it.p.id) line = x; });
        if (!line) { lines.push(it.p.name + ' não está na comanda ' + c.name + '.'); return; }
        if (it.qty === null || it.qty >= line.q) { ops.push({ t: 'com.remove', cid: c.id, pid: it.p.id }); lines.push('Tirei ' + it.p.name + ' da comanda ' + c.name + '.'); }
        else { for (var k = 0; k < it.qty; k++) ops.push({ t: 'com.dec', cid: c.id, pid: it.p.id }); lines.push('Tirei ' + it.qty + ' un de ' + it.p.name + ' da comanda ' + c.name + '.'); }
      });
      if (!ops.length) return say(lines.join('\n'));
      runOps(ops).then(function(r){ if (!r.ok) return fail(r); say(lines.join('\n') + '\nO estoque foi devolvido.'); });
    });
  }, false);
}
function actComOpen(ref){
  if (!ref.rest) {
    return ask('Qual o nome da comanda? (ex: Mesa 3, João)', null, function(raw, t){ if (again(raw, t)) return; actComOpen({ kw: 'comanda', rest: norm(raw), rawRest: raw, label: norm(raw), name: tidy(raw) }); });
  }
  var ex = findComandas(ref.label).filter(function(c){ return norm(c.name) === norm(ref.name); });
  if (ex.length) return say('A comanda **' + ex[0].name + '** já está aberta. Quer colocar itens nela?');
  runOps([{ t: 'com.new', cid: 'c' + E.uid(), name: ref.name }]).then(function(r){ if (!r.ok) return fail(r); say('Abri a comanda **' + ref.name + '**. Pode mandar os itens: “2 heineken na ' + ref.name.toLowerCase() + '”.'); });
}
function actComClose(ref, pay){
  pickComanda(ref, null, function(c){
    if (!c.items || !c.items.length) return say('A comanda **' + c.name + '** está vazia. Quer cancelá-la?', ['Cancelar comanda ' + c.name]);
    var total = c.items.reduce(function(s, i){ return s + i.price * i.q; }, 0);
    var go = function(pm){
      confirm('Fechar **' + c.name + '** (' + c.items.reduce(function(s, i){ return s + i.q; }, 0) + ' un, **' + E.money(total) + '**) no ' + pm + '?', function(){
        runOps([{ t: 'com.close', cid: c.id, pay: pm }]).then(function(r){ if (!r.ok) return fail(r); say('Comanda fechada: ' + E.money(total) + ' no ' + pm + '.'); });
      });
    };
    if (pay && pay !== 'cartao') go(pay); else askPay(go, pay === 'cartao' ? 'Débito ou crédito?' : null);
  }, false);
}
function actComCancel(ref){
  pickComanda(ref, null, function(c){
    confirm('Cancelar a comanda **' + c.name + '**? Os itens voltam pro estoque.', function(){
      runOps([{ t: 'com.cancel', cid: c.id }]).then(function(r){ if (!r.ok) return fail(r); say('Comanda ' + c.name + ' cancelada. Estoque devolvido.'); });
    });
  }, false);
}
function actSetPrice(prodText, price){
  if (noAdmin()) return;
  resolveAll([{ qty: null, text: prodText }], false, function(items){
    var p = items[0].p;
    confirm('Mudar o preço de ' + pname(p) + ' de ' + E.money(p.price) + ' para **' + E.money(price) + '**?', function(){
      runOps([{ t: 'product.save', pid: p.id, d: { name: p.name, cat: p.cat, price: price, cost: p.cost, qty: p.qty, min: p.min } }]).then(function(r){ if (!r.ok) return fail(r); say('Preço de ' + pname(p) + ' agora é ' + E.money(price) + '.'); });
    });
  });
}
function actSetQty(prodText, qty){
  if (noAdmin()) return;
  resolveAll([{ qty: null, text: prodText }], false, function(items){
    var p = items[0].p;
    confirm('Acertar o estoque de ' + pname(p) + ' de ' + p.qty + ' para **' + qty + '** un?', function(){
      runOps([{ t: 'product.save', pid: p.id, d: { name: p.name, cat: p.cat, price: p.price, cost: p.cost, qty: qty, min: p.min } }]).then(function(r){ if (!r.ok) return fail(r); say('Pronto, ' + pname(p) + ' agora tem ' + qty + ' un.'); });
    });
  });
}

/* ---------- consultas ---------- */
function qStock(text){
  var S = E.S();
  if (!text) {
    var low = S.products.filter(function(p){ return p.qty <= p.min; });
    return say('Você tem **' + S.products.length + '** produtos no estoque' + (low.length ? ', e **' + low.length + '** estão baixos ou zerados.' : ', todos em dia.'), low.length ? ['O que está acabando?'] : null);
  }
  var f = findProds(text);
  if (!f.list.length) return say('Não achei “' + text + '” no estoque.');
  say(f.list.slice(0, 8).map(function(p){ return '**' + p.name + '**: ' + p.qty + ' un' + (p.qty <= 0 ? ' (zerado)' : p.qty <= p.min ? ' (baixo)' : '') + (E.isAdmin() ? '' : ''); }).join('\n') + (f.list.length > 8 ? '\n…e mais ' + (f.list.length - 8) + '.' : ''));
}
function qLow(){
  var ls = E.S().products.filter(function(p){ return p.qty <= p.min; }).sort(function(a, b){ return a.qty - b.qty; });
  if (!ls.length) return say('Nada acabando. Todo o estoque está acima do mínimo.');
  say('Estão baixos ou zerados:\n' + ls.slice(0, 12).map(function(p){ return '• ' + p.name + ': ' + p.qty + ' un'; }).join('\n') + (ls.length > 12 ? '\n…e mais ' + (ls.length - 12) + '.' : ''));
}
function qPrice(text){
  var f = findProds(text);
  if (!f.list.length) return say('Não achei “' + text + '” no estoque.');
  say(f.list.slice(0, 8).map(function(p){ return '**' + p.name + '**: ' + E.money(p.price); }).join('\n'));
}
function qToday(){
  if (!E.isAdmin()) return say('O faturamento do dia só o administrador vê. Posso te dizer as comandas abertas ou o estoque.');
  var d = new Date(); d.setHours(0, 0, 0, 0);
  var ss = E.S().sales.filter(function(s){ return s.t >= d.getTime(); }), tot = ss.reduce(function(a, s){ return a + s.total; }, 0);
  say('Hoje foram **' + ss.length + '** venda' + (ss.length === 1 ? '' : 's') + ', somando **' + E.money(tot) + '**.');
}
function qComandas(){
  var cs = E.S().comandas;
  if (!cs.length) return say('Não tem nenhuma comanda aberta.');
  say('Comandas abertas:\n' + cs.map(function(c){ return '• ' + c.name + ': ' + E.money(c.items.reduce(function(s, i){ return s + i.price * i.q; }, 0)); }).join('\n'));
}
var EXAMPLES = ['Adicionar produto ao estoque', 'Vendi 2 Heineken no Pix', 'Abre a comanda Mesa 3', 'Quanto tem de Heineken?', 'O que está acabando?'];
function help(){
  say('Eu entendo frases como:\n• “Adiciona 20 Heineken ao estoque”\n• “Novo produto” (eu pergunto o resto)\n• “Vendi 2 cachaça no Pix”\n• “Abre a comanda Mesa 3”\n• “Coloca 2 Heineken na mesa 3”\n• “Tira 1 Heineken da mesa 3”\n• “Fecha a mesa 3 no Pix”\n• “Quanto tem de vinho?”, “O que está acabando?”\n• “Quanto vendi hoje?”, “Comandas abertas”\n• “Muda o preço da Heineken para 10”\n• “Tira 5 Gelo do estoque” (quebrou, perdi...)\nSe faltar alguma informação, eu pergunto.', EXAMPLES);
}

/* ---------- roteador de frases ---------- */
function route(raw, t0){
  var X = strip(raw), n = X.n;
  if (!n || /^(oi|ola|opa|e ai|fala|hey|ei|bom dia|boa tarde|boa noite|tudo bem|oi tudo bem)$/.test(n)) return say('Oi, ' + E.userName() + '! O que você precisa?', EXAMPLES);
  if (/^(ajuda|help|socorro|comandos|o que (voce|vc|tu) (faz|sabe|pode)|como (funciona|uso|usa))/.test(n)) return help();
  if (/^(obrigad|brigad|valeu|vlw|show|top|legal)/.test(n)) return say('Por nada!');
  var m;
  /* consultas */
  if (/(acabando|acabou|estoque baixo|em falta|zerad|precis\w* (comprar|repor)|o que (falta|repor)|baixo)/.test(n) && !/\d/.test(n) && !/^(adiciona|coloca|tira)/.test(n)) return qLow();
  if (/\bcomandas?\s+abertas?\b|^(quais|mostra|lista|ver)\b.*\bcomandas\b|^comandas$/.test(n)) return qComandas();
  if (/^quanto\b.*\b(vend|fatur)|\b(vendas|faturamento|vendi)\b.*\bhoje\b|^(vendas|faturamento) (de )?hoje/.test(n)) return qToday();
  if (/\b(quanto custa|preco|valor)\b/.test(n) && !/(muda|altera|troca|atualiza|coloca|define|ajusta|aumenta)/.test(n)) {
    var pt = n.replace(/^.*?\b(?:quanto custa|preco|valor)\b\s*(?:de |do |da |dos |das )?(?:um |uma )?/, ''); return pt ? qPrice(pt) : say('De qual produto?');
  }
  if (/^(quanto|quantos|quantas|qual)\b.*\b(tem|temos|resta|restam|sobrou|sobraram|estoque|saldo|sobra)\b|^estoque\b|^tem\b|^temos\b/.test(n) && !/\b(comanda|mesa)\b/.test(n)) {
    var q = n.replace(/^(quanto|quantos|quantas|qual)\s+(?:que\s+)?(?:ainda\s+)?(?:tem|temos|resta|restam|sobrou|sobraram|sobra|e|o|eh)?\s*/, '').replace(/^(?:o\s+)?(?:estoque|saldo)\s*/, '').replace(/^(?:tem|temos)\s*/, '').replace(/\b(no|do|em) estoque\b/g, '').replace(/^(de |do |da |dos |das |ainda )+/, '').trim();
    return qStock(q.replace(/\?$/, ''));
  }
  /* comandas */
  var ref = /\b(comanda|mesa)\b/.test(n) ? comLabel(X) : null;
  if (ref) {
    var before = X.r.slice(0, Math.max(0, ref.idx)), bn = X.n.slice(0, Math.max(0, ref.idx));
    if (/^(abr|cri|nov|faz|inici|comec)\w*/.test(n)) return actComOpen(ref);
    if (/^(fech|encerr|finaliz|receb|pag)\w*/.test(n)) { var pay = detectPay(X); ref = comLabel(X) || ref; return actComClose(ref, pay); }
    if (/^(cancel|apag|exclu|delet)\w*/.test(n)) return actComCancel(ref);
    if (/^(tir|remov|retir|diminu)\w*/.test(n)) { var its = parseItems(before.replace(/^\S+\s*/, '').replace(/\s+(?:da|na|de|do|no|em)\s*$/i, '')); return its.length ? actComRemove(its, ref) : say('Qual item tirar da comanda?'); }
    var body = before.replace(/^(coloca\w*|po[ei]\w*|bota\w*|adiciona\w*|anota\w*|lanca\w*|manda\w*|inclu\w*|add|mais)\s+/i, '').replace(/\s+(?:na|da|pra|para|em|no|a|à|do|de)\s*$/i, '');
    var items = parseItems(body);
    if (items.length) return actComAdd(items, ref);
    return say('Quais itens quer colocar na comanda **' + ref.name + '**? Ex: “2 Heineken”.');
  }
  /* venda */
  if (/^(vend|venda|registr\w* (a )?venda|saiu|sairam|sai)/.test(n)) {
    var pay2 = detectPay(X);
    var body2 = X.r.replace(/^(registr\w*\s+(?:uma\s+)?venda|vend\w*|venda|saiu|sairam|sai)\s*(?:de\s+|uma\s+)?/i, '');
    var its2 = parseItems(body2);
    return its2.length ? actSale(its2, pay2) : say('O que você vendeu? Ex: “vendi 2 Heineken no Pix”.');
  }
  /* preço / estoque: ajustes */
  m = n.match(/(?:preco|valor)\s+(?:de |do |da |dos |das )?(.+?)\s+(?:para|pra|em|=|por)\s*(?:r\$\s*)?(\d[\d.,]*)/);
  if (m && /^(muda|mude|altera|troca|atualiza|coloca|define|ajusta|aumenta|seta|corrige)/.test(n)) return actSetPrice(m[1], parsePrice(m[2]));
  m = n.match(/estoque\s+(?:de |do |da |dos |das )?(.+?)\s+(?:para|pra|em|=)\s*(\d+)\b/);
  if (m && /^(ajust|acert|defin|atualiz|corrig|mud|alter|set)/.test(n)) return actSetQty(m[1], +m[2]);
  if (/^(tir|remov|baix|retir|perdi|quebr|descart|estragou|vencer|vencid)\w*/.test(n)) {
    var b3 = X.r.replace(/^\S+\s*/, '').replace(/\b(?:do|no|de) estoque\b/i, '');
    var its3 = parseItems(b3); return its3.length ? actStockSub(its3) : say('O que tirar do estoque? Ex: “tira 5 Gelo do estoque”.');
  }
  /* estoque: adicionar */
  if (/^(adicion\w*|acrescent\w*|colo\w*|po[ei]\w*|bot\w*|repo\w*|repor|reabastec\w*|cheg\w*|entr\w*|receb\w*|compr\w*|cadastr\w*|cri\w*|nov[ao]|inclu\w*|add)\b/.test(n)) {
    var b4 = X.r.replace(/^(?:adicion\w*|acrescent\w*|colo\w*|po[ei]\w*|bot\w*|repo\w*|repor|reabastec\w*|cheg\w*|entr\w*|receb\w*|compr\w*|cadastr\w*|cri\w*|nov[ao]|inclu\w*|add)\s*/i, '')
      .replace(/\b(?:ao|no|do|de|em)\s+estoque\b/ig, '').replace(/^(?:um\s+|uma\s+)?(?:novo\s+|nova\s+)?produtos?\s*(?:novo\s*)?/i, '').replace(/^(?:de|do|da)\s+/i, '').trim();
    var its4 = parseItems(b4);
    if (!its4.length) return ask('Qual produto e quantas unidades? (ex: Heineken, 20 unidades)', null, function(r2, t2){
      if (again(r2, t2)) return;
      var it2 = parseItems(r2); if (!it2.length) return say('Não entendi. Tente: “Heineken, 20 unidades”.');
      actStockAdd(it2);
    });
    return actStockAdd(its4);
  }
  /* “Heineken, 20 unidades” sozinho */
  var bare = parseItems(X.r);
  if (bare.length && bare.every(function(x){ return x.text && x.qty !== null; }) && X.r.split(/\s+/).length <= 8 && !/\?$/.test(raw)) {
    return confirm('Quer adicionar ' + bare.map(function(x){ return x.qty + ' un de ' + tidy(x.text); }).join(' e ') + ' ao estoque?', function(){ actStockAdd(bare); });
  }
  say('Não entendi essa. Eu sei mexer no estoque, nas vendas e nas comandas. Diga “ajuda” pra ver exemplos.', EXAMPLES);
}

/* ---------- tela ---------- */
function draw(){
  var log = $('#chat-log'); if (!log) return;
  var last = CH.msgs.length - 1;
  log.innerHTML = CH.msgs.map(function(m, i){
    var h = '<div class="msg ' + m.who + (i === last ? ' last' : '') + '">' + fmt(m.text) + '</div>';
    if (i === last && m.who === 'bot' && m.chips) h += '<div class="chips">' + m.chips.map(function(c){ return '<button type="button" class="chip" data-chip="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>';
    return h;
  }).join('');
  log.scrollTop = log.scrollHeight;
}
function submit(raw){
  raw = String(raw || '').replace(/\s+/g, ' ').trim(); if (!raw) return;
  CH.msgs.push({ who: 'me', text: raw });
  var t = strip(raw).n, p = CH.pend; CH.pend = null;
  try {
    if (p) { if (isCancel(t)) say('Tudo bem, cancelei.'); else p.h(raw, t); }
    else route(raw, t);
  } catch (e) { say('Deu um erro aqui (' + e.message + '). Tente de novo de outro jeito.'); }
  draw();
}
function fit(){
  var c = $('#chat'); if (!c || c.hidden) return;
  var vv = window.visualViewport; c.style.height = vv ? vv.height + 'px' : '';
  c.style.top = vv ? vv.offsetTop + 'px' : '';
  var log = $('#chat-log'); if (log) log.scrollTop = log.scrollHeight;
}
function open(){
  if (!E.ready() || E.chatOff()) return;
  var c = $('#chat'); c.hidden = false; CH.open = true; document.body.classList.add('lock');
  if (!CH.started) { CH.started = true; say('Oi, ' + E.userName() + '! Sou a ADEGA, sua assistente. Eu mexo no estoque, registro vendas e cuido das comandas. É só escrever do seu jeito.', EXAMPLES); }
  draw(); fit();
  setTimeout(function(){ var i = $('#chat-in'); if (i) i.focus(); }, 60);
}
function close(){
  var c = $('#chat'); if (!c) return; c.hidden = true; CH.open = false;
  var sh = $('#sheet'); if (!sh || sh.hidden) document.body.classList.remove('lock');
}
function build(){
  var d = document.createElement('div'); d.id = 'chat'; d.hidden = true;
  d.innerHTML = '<div class="chat-in" role="dialog" aria-label="Conversa com a ADEGA">' +
    '<div class="chat-h"><div class="mark"><svg viewBox="0 0 24 24"><path d="M10 2h4v4l1.5 3v11a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V9L10 6z"/><path d="M8.5 13h7"/></svg></div><div class="grow"><h2>ADEGA</h2><small>assistente da adega</small></div><button type="button" class="rnd x" id="chat-x" aria-label="Fechar conversa">✕</button></div>' +
    '<div id="chat-log" aria-live="polite"></div>' +
    '<form id="chat-form" autocomplete="off"><input id="chat-in" type="text" placeholder="Fale com a ADEGA…" enterkeyhint="send" autocapitalize="sentences" aria-label="Mensagem"><button class="btn primary" type="submit">Enviar</button></form></div>';
  document.body.appendChild(d);
  $('#chat-x').addEventListener('click', close);
  $('#chat-form').addEventListener('submit', function(e){ e.preventDefault(); var i = $('#chat-in'); var v = i.value; i.value = ''; submit(v); i.focus(); });
  $('#chat-log').addEventListener('click', function(e){ var b = e.target.closest('[data-chip]'); if (b) submit(b.getAttribute('data-chip')); });
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && CH.open) close(); });
  if (window.visualViewport) { window.visualViewport.addEventListener('resize', fit); window.visualViewport.addEventListener('scroll', fit); }
  var b = $('#chatbtn'); if (b) b.addEventListener('click', open);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
window.EguaChat = { submit: submit, open: open, close: close };
})();
