(function(){
'use strict';

/* =====================================================================
   Égua da Cachaça — estoque, venda e comanda
   Dois jeitos de rodar:
   • LAN  — dentro do app instalado (APK). O próprio celular da adega é o
            servidor; os outros celulares abrem uma página pelo Wi-Fi.
   • local — só HTML (sem servidor): os dados ficam neste aparelho.
   Em ambos, TODA mudança é uma "operação" aplicada pela mesma função
   (reduce) — por isso todos os celulares chegam sempre ao mesmo estoque.
   ===================================================================== */

var KEY = 'adega-controle-v1', PREFKEY = 'adega-prefs-v1', TOKKEY = 'egua-token';
var PAYS = ['Dinheiro', 'Pix', 'Débito', 'Crédito'];
var RM = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
var SEED = [
  ['Heineken long neck 330ml', 'Cerveja', 950, 560, 48, 24],
  ['Cerveja lata 350ml', 'Cerveja', 450, 270, 72, 36],
  ['Vinho tinto 750ml', 'Vinho', 8900, 5200, 10, 4],
  ['Espumante brut 750ml', 'Espumante', 7500, 4300, 6, 3],
  ['Cachaça artesanal 700ml', 'Destilado', 4900, 2800, 14, 6],
  ['Whisky 1L', 'Destilado', 12900, 8400, 2, 3],
  ['Água sem gás 500ml', 'Outros', 400, 150, 30, 12],
  ['Gelo 5kg', 'Outros', 1200, 600, 0, 5]
];
var ICONS = {
  comandas: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>',
  venda: '<svg viewBox="0 0 24 24"><path d="M3 4h2l2.4 11h10.2L20 8H6.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/></svg>',
  estoque: '<svg viewBox="0 0 24 24"><path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/></svg>',
  caixa: '<svg viewBox="0 0 24 24"><path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l12-3v3"/><circle cx="16.5" cy="13.5" r="1"/></svg>',
  ajustes: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>'
};
var LABELS = { comandas: 'Comandas', venda: 'Venda', estoque: 'Estoque', caixa: 'Caixa', ajustes: 'Ajustes' };
var LOGO = '<svg viewBox="0 0 24 24"><path d="M10 2h4v4l1.5 3v11a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V9L10 6z"/><path d="M8.5 13h7"/></svg>';

var $ = function(s){ return document.querySelector(s); };
var A = function(s){ return document.querySelector('.page[data-v="' + view + '"] ' + s); };
var pageEl = function(v){ return document.querySelector('.page[data-v="' + v + '"]'); };

/* ---------- estado ---------- */
var P = loadPrefs();                 // preferências do aparelho (tema, animações)
var S = null;                        // dados da adega (iguais em todos os celulares)
var M = { mode: 'local', host: true, role: 'admin', id: 'host', token: '', ips: [], port: 0, peers: {}, online: true,
          ready: false, epoch: '', seq: 0, snapSeq: 0, top: 0, gen: 0, inv: null, ipSel: 0, compacting: false, ver: null, upd: null, updAt: 0 };
var VIEWS = ['comandas', 'venda', 'estoque', 'caixa', 'ajustes'];
var view = 'venda', cart = {}, pay = 'Pix', cur = null, armed = null, lastKey = '', lastToday = 0;
var F = { q: '', qp: '', low: false, range: 'today', cat: '' };
var pending = {};
function loadPrefs(){
  var d = { theme: 'auto', anim: 'on', chat: 'on', skin: 'egua' };
  try { var r = localStorage.getItem(PREFKEY); if (r) return Object.assign(d, JSON.parse(r)); } catch (e) {}
  try { // aproveita o que já existia na versão anterior
    var old = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (old && old.cfg) { if (old.cfg.theme) d.theme = old.cfg.theme; if (old.cfg.anim) d.anim = old.cfg.anim; }
  } catch (e) {}
  return d;
}
function savePrefs(){ try { localStorage.setItem(PREFKEY, JSON.stringify(P)); } catch (e) {} }

/* ---------- dados ---------- */
function emptyState(){ return { v: 1, adega: 'Égua da Cachaça', cc: 0, seeded: false, products: [], comandas: [], sales: [], members: [] }; }
function seedInto(St){
  SEED.forEach(function(r, i){ St.products.push({ id: 'ex' + (i + 1), name: r[0], cat: r[1], price: r[2], cost: r[3], qty: r[4], min: r[5], ex: true }); });
  St.seeded = true;
}
function localNew(name){
  var s = emptyState(); s.members.push({ id: 'host', name: name || 'Mateus', role: 'admin', t: 0 }); seedInto(s); return s;
}
function normalize(o){ // aceita dados da versão antiga e backups
  var s = emptyState(), ids = function(a){ return String(a); };
  s.adega = o.adega || (o.cfg && o.cfg.adega) || s.adega;
  s.cc = o.cc || 0; s.seeded = true;
  s.products = (o.products || []).map(function(p){ var x = { id: ids(p.id), name: String(p.name), cat: String(p.cat || 'Outros'), price: p.price | 0, cost: p.cost | 0, qty: p.qty | 0, min: p.min | 0 }; if (p.ex) x.ex = true; if (p.img) x.img = Number(p.img); if (typeof p.imgData === 'string') x.imgData = p.imgData; return x; });
  var items = function(a){ return (a || []).map(function(i){ return { pid: ids(i.pid), name: String(i.name), price: i.price | 0, cost: i.cost | 0, q: i.q | 0 }; }); };
  s.comandas = (o.comandas || []).map(function(c){ var x = { id: ids(c.id), name: String(c.name), t: c.t || 0, items: items(c.items) }; if (c.by) x.by = c.by; return x; });
  s.sales = (o.sales || []).map(function(c){ var x = { id: ids(c.id), t: c.t || 0, pay: c.pay || 'Dinheiro', total: c.total | 0, items: items(c.items) }; if (c.com) x.com = c.com; if (c.by) x.by = c.by; if (c.uid) x.uid = c.uid; return x; });
  if (Array.isArray(o.members) && o.members.length) s.members = o.members;
  else s.members = [{ id: 'host', name: (o.cfg && o.cfg.user) || o.user || 'Mateus', role: 'admin', t: 0 }];
  return s;
}
function validBackup(o){ return o && Array.isArray(o.products) && Array.isArray(o.comandas) && Array.isArray(o.sales); }
function loadLocal(){
  try { var o = JSON.parse(localStorage.getItem(KEY) || 'null'); if (validBackup(o)) return normalize(o); } catch (e) {}
  return localNew();
}
function saveLocal(){ if (M.mode === 'local') { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} } }
function fromSnap(str){
  try { var o = JSON.parse(str); if (validBackup(o) && Array.isArray(o.members)) return o; } catch (e) {}
  return emptyState();
}

var origTheme = document.documentElement.getAttribute('data-theme');
var SKINS = [['egua', 'Égua', '#9a5200', 'Padrão'], ['aurora', 'Aurora', '#6d3fc4', 'Roxo'], ['carmesim', 'Carmesim', '#b3122b', 'Vermelho'], ['neve', 'Neve', '#ffffff', 'Branco'], ['esmeralda', 'Esmeralda', '#0b7a4a', 'Verde'], ['iphone', 'Modo iPhone', 'linear-gradient(135deg,#0a84ff,#bf5af2)', 'Liquid Glass']];
function skinPicker(){
  return '<div class="skins">' + SKINS.map(function(s){
    return '<button class="skin" data-act="skin" data-v="' + s[0] + '" aria-pressed="' + (P.skin === s[0]) + '"><i style="background:' + s[2] + '"></i><span><b>' + s[1] + '</b><small>' + s[3] + '</small></span></button>';
  }).join('') + '</div>';
}
function applyTheme(){
  var t = 'auto', r = document.documentElement;
  if (SKINS.map(function(s){ return s[0]; }).indexOf(P.skin) < 0) P.skin = 'egua';
  if (P.skin === 'egua') r.removeAttribute('data-skin'); else r.setAttribute('data-skin', P.skin);
  if (P.skin === 'neve') r.setAttribute('data-theme', 'light');
  else if (t === 'light' || t === 'dark') r.setAttribute('data-theme', t);
  else if (origTheme) r.setAttribute('data-theme', origTheme);
  else r.removeAttribute('data-theme');
  try { var mt = document.querySelector('meta[name="theme-color"]'); if (mt) mt.setAttribute('content', getComputedStyle(r).getPropertyValue('--accent').trim() || '#9a5200'); } catch (e) {}
}
function animOn(){ return P.anim === 'on' || !RM; }
function applyChat(){ var b = document.getElementById('chatbtn'); if (b) b.hidden = P.chat === 'off'; if (P.chat === 'off' && window.EguaChat) window.EguaChat.close(); }
function applyAnim(){ document.documentElement.classList.toggle('anim', animOn()); }

/* ---------- utilidades ---------- */
function esc(s){ return String(s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function money(c){ return (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
function fm(c){ return (c / 100).toFixed(2).replace('.', ','); }
function pm(v){
  v = String(v || '').replace(/[^\d,.]/g, '');
  if (v.indexOf(',') > -1) v = v.replace(/\./g, '').replace(',', '.');
  var n = parseFloat(v); return isFinite(n) ? Math.round(n * 100) : 0;
}
function norm(s){ return String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
function byId(a, id){ for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i]; return null; }
function Pr(id){ return byId(S.products, id); }
function comById(id){ return byId(S.comandas, id); }
function saleById(id){ return byId(S.sales, id); }
function hhmm(t){ return new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function dhm(t){ return new Date(t).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' ' + hhmm(t); }
function startOfDay(){ var d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); }
function toast(m){ var t = $('#toast'); t.hidden = true; t.textContent = m; void t.offsetWidth; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function(){ t.hidden = true; }, 2600); }
function empty(t, p){ return '<div class="empty"><b>' + t + '</b><p>' + p + '</p></div>'; }
function sum(a, f){ return a.reduce(function(x, i){ return x + f(i); }, 0); }
function rs(i){ return i < 10 ? ' style="--d:' + i + '"' : ''; }
function comTotal(c){ return sum(c.items, function(i){ return i.price * i.q; }); }
function profit(s){ return sum(s.items, function(i){ return (i.price - i.cost) * i.q; }); }
function photoUrl(p){
  if (!p) return '';
  if (p.imgData) return p.imgData;
  return (M.mode === 'lan' && p.img) ? '/photos/' + encodeURIComponent(p.id) + '.jpg?v=' + p.img : '';
}
function thumb(p){
  var u = photoUrl(p);
  return '<span class="thumb"' + (u ? ' data-act="photo" data-id="' + esc(p.id) + '"' : '') + '>' + (u ? '<img loading="lazy" alt="" src="' + esc(u) + '">' : LOGO) + '</span>';
}
function fileToJpeg(file, maxSide){
  return new Promise(function(res, rej){
    var url = URL.createObjectURL(file), img = new Image();
    img.onload = function(){
      var w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, (maxSide || 420) / Math.max(w, h));
      var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
      var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      try { res(c.toDataURL('image/jpeg', 0.75)); } catch (e) { rej(e); }
    };
    img.onerror = function(){ URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
function dataToBytes(u){ var b = atob(u.split(',')[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
function savePhoto(pid, url){
  if (!url) {
    if (M.mode === 'lan') api('/api/photo?id=' + encodeURIComponent(pid), { method: 'DELETE' }).catch(function(){});
    return dispatch({ t: 'product.photo', pid: pid, v: 0 }).then(refreshAll);
  }
  var v = Date.now();
  if (M.mode === 'local') return dispatch({ t: 'product.photo', pid: pid, v: v, data: url }).then(refreshAll);
  return api('/api/photo?id=' + encodeURIComponent(pid), { method: 'POST', body: dataToBytes(url), timeout: 30000 }).then(function(r){
    if (!(r.j && r.j.ok)) throw new Error('up');
    return dispatch({ t: 'product.photo', pid: pid, v: v });
  }).then(refreshAll).catch(function(){ toast('Produto salvo, mas a foto não foi enviada.'); });
}
function multi(){ return M.mode === 'lan'; }
function isAdmin(){ return M.role === 'admin'; }
function member(id){ return byId(S.members, id); }
function userName(){ var m = S && member(M.id); return m ? m.name : (M.host ? 'Mateus' : 'Você'); }
function adegaName(){ return (S && S.adega) || 'Égua da Cachaça'; }
function uid(){
  var a = new Uint8Array(9), s = '';
  try { (window.crypto || window.msCrypto).getRandomValues(a); } catch (e) { for (var k = 0; k < 9; k++) a[k] = Math.floor(Math.random() * 256); }
  for (var i = 0; i < a.length; i++) s += (a[i] % 36).toString(36);
  return s;
}
function salesIn(range){
  var from = range === 'today' ? startOfDay() : range === '7d' ? startOfDay() - 6 * 864e5 : 0;
  return S.sales.filter(function(s){ return s.t >= from; }).sort(function(a, b){ return b.t - a.t; });
}
function lowCount(){ return S.products.filter(function(p){ return p.qty <= p.min; }).length; }
function cartLines(){ return Object.keys(cart).map(function(id){ var p = Pr(id); return p ? { p: p, q: cart[id] } : null; }).filter(Boolean); }
function cartTotal(){ return sum(cartLines(), function(l){ return l.p.price * l.q; }); }
function cartCount(){ return sum(cartLines(), function(l){ return l.q; }); }
function confirmAct(key, el, fn){
  if (armed === key) { armed = null; fn(); return; }
  armed = key; var old = el.textContent; el.textContent = 'Toque de novo para confirmar'; el.classList.add('armed');
  setTimeout(function(){ if (armed === key) { armed = null; if (el.isConnected) { el.textContent = old; el.classList.remove('armed'); } } }, 4000);
}
function tween(el, to, from){
  if (!animOn() || from === to) { el.textContent = money(to); return; }
  var t0 = performance.now(), d = 480;
  (function f(t){
    var k = Math.min(1, (t - t0) / d), e = 1 - Math.pow(1 - k, 3);
    el.textContent = money(Math.round(from + (to - from) * e));
    if (k < 1) requestAnimationFrame(f);
  })(t0);
}
function tweenAll(root){ root.querySelectorAll('[data-money]').forEach(function(el){ tween(el, +el.dataset.money, 0); }); }
function exNote(){
  return (isAdmin() && S.products.some(function(p){ return p.ex; }))
    ? '<div class="note"><span>Produtos de exemplo. Troque pelos da adega.</span><button class="btn" data-act="rm-ex">Remover exemplos</button></div>' : '';
}
function seg(id, opts, sel){
  return '<div class="seg" style="--n:' + opts.length + ';--i:' + sel + '"><span class="seg-thumb"></span>' +
    opts.map(function(o, i){ return '<button data-act="seg" data-seg="' + id + '" data-v="' + o[0] + '" data-i="' + i + '" aria-pressed="' + (i === sel) + '">' + o[1] + '</button>'; }).join('') + '</div>';
}
function copyText(t, okMsg){
  var fb = function(){ cur = { t: 'bk-text', txt: t }; renderSheet(); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function(){ toast(okMsg); }, fb);
  else fb();
}
function qrSvg(text){
  var q = window.qrcode(0, 'M'); q.addData(text); q.make();
  var n = q.getModuleCount(), m = 1, d = '';
  for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + m) + ' ' + (r + m) + 'h1v1h-1z';
  var z = n + 2 * m;
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + z + ' ' + z + '" shape-rendering="crispEdges"><rect width="' + z + '" height="' + z + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
}

/* =====================================================================
   REGRAS (reduce): a MESMA função roda em todos os celulares.
   env = { m: quem fez, r: função dele (admin/staff), ts: hora do servidor, op }
   ===================================================================== */
function ni(x, min, max){ x = Math.floor(Number(x)); if (!isFinite(x)) return null; return x < min || x > max ? null : x; }
function ns(x, max){ return String(x == null ? '' : x).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function nameOf(St, id){ var m = byId(St.members, id); return m ? m.name : ''; }
function mkSale(St, env, sid, payMode, items, com){
  if (byId(St.sales, sid)) return { ok: true, dup: true };
  var s = { id: sid, t: env.ts, pay: payMode, total: sum(items, function(i){ return i.price * i.q; }), by: nameOf(St, env.m), uid: env.m, items: items };
  if (com) s.com = com;
  St.sales.push(s);
  return { ok: true, total: s.total, sid: sid };
}
function reduce(St, env){
  var o = env.op || {}, adm = env.r === 'admin', i, p, c, d, q;
  switch (o.t) {
    case 'adega.rename':
      if (!adm) return { ok: false, err: 'role' };
      St.adega = ns(o.name, 60) || St.adega; return { ok: true };
    case 'member.join': {
      var nm = ns(o.name, 40) || 'Atendente', mm = byId(St.members, env.m);
      if (mm) mm.name = nm; else St.members.push({ id: env.m, name: nm, role: env.r, t: env.ts });
      return { ok: true };
    }
    case 'member.rename':
      mm = byId(St.members, env.m); if (!mm) return { ok: false, err: 'notfound' };
      mm.name = ns(o.name, 40) || mm.name; return { ok: true };
    case 'member.remove':
      if (!adm) return { ok: false, err: 'role' };
      St.members = St.members.filter(function(x){ return x.id !== o.id || x.id === 'host'; }); return { ok: true };
    case 'product.seed':
      if (!adm) return { ok: false, err: 'role' };
      if (!St.seeded && !St.products.length) seedInto(St);
      St.seeded = true; return { ok: true };
    case 'product.rmex':
      if (!adm) return { ok: false, err: 'role' };
      St.products = St.products.filter(function(x){ return !x.ex; }); return { ok: true };
    case 'product.save': {
      if (!adm) return { ok: false, err: 'role' };
      d = o.d || {};
      var nme = ns(d.name, 80), price = ni(d.price, 1, 1e8), cost = ni(d.cost, 0, 1e8), qty = ni(d.qty, 0, 1e6), min = ni(d.min, 0, 1e6);
      if (!nme || price === null || cost === null || qty === null || min === null || !/^[A-Za-z0-9_-]{1,40}$/.test(String(o.pid))) return { ok: false, err: 'invalid' };
      var rec = { id: String(o.pid), name: nme, cat: ns(d.cat, 40) || 'Outros', price: price, cost: cost, qty: qty, min: min };
      p = byId(St.products, rec.id);
      if (p) { Object.keys(rec).forEach(function(k){ p[k] = rec[k]; }); delete p.code; delete p.ex; } else St.products.push(rec);
      return { ok: true };
    }
    case 'product.photo': {
      if (!adm) return { ok: false, err: 'role' };
      p = byId(St.products, String(o.pid)); if (!p) return { ok: false, err: 'notfound' };
      var pv = ni(o.v, 0, 9e15); if (pv === null) return { ok: false, err: 'invalid' };
      if (!pv) { delete p.img; delete p.imgData; }
      else { p.img = pv; if (typeof o.data === 'string' && o.data.indexOf('data:image/jpeg;base64,') === 0 && o.data.length < 200000) p.imgData = o.data; else delete p.imgData; }
      return { ok: true };
    }
    case 'product.delete':
      if (!adm) return { ok: false, err: 'role' };
      St.products = St.products.filter(function(x){ return x.id !== o.pid; }); return { ok: true };
    case 'sale.create': {
      var lines = Array.isArray(o.lines) ? o.lines : [], need = {}, items = [];
      if (!lines.length || lines.length > 200 || PAYS.indexOf(o.pay) < 0 || !/^[A-Za-z0-9_-]{1,40}$/.test(String(o.sid))) return { ok: false, err: 'invalid' };
      for (i = 0; i < lines.length; i++) { q = ni(lines[i].q, 1, 9999); if (q === null) return { ok: false, err: 'invalid' }; need[lines[i].pid] = (need[lines[i].pid] || 0) + q; }
      for (var pid in need) { p = byId(St.products, pid); if (!p) return { ok: false, err: 'notfound' }; if (p.qty < need[pid]) return { ok: false, err: 'stock:' + p.name }; }
      if (byId(St.sales, o.sid)) return { ok: true, dup: true };
      for (pid in need) { p = byId(St.products, pid); p.qty -= need[pid]; items.push({ pid: pid, name: p.name, price: p.price, cost: p.cost, q: need[pid] }); }
      return mkSale(St, env, String(o.sid), o.pay, items, '');
    }
    case 'com.new':
      if (!/^[A-Za-z0-9_-]{1,40}$/.test(String(o.cid))) return { ok: false, err: 'invalid' };
      if (byId(St.comandas, o.cid)) return { ok: true, cid: o.cid };
      St.cc = (St.cc || 0) + 1;
      St.comandas.push({ id: String(o.cid), name: ns(o.name, 40) || ('Comanda ' + St.cc), t: env.ts, by: nameOf(St, env.m), items: [] });
      return { ok: true, cid: o.cid };
    case 'com.add':
      c = byId(St.comandas, o.cid); p = byId(St.products, o.pid);
      if (!c || !p) return { ok: false, err: 'notfound' };
      if (p.qty <= 0) return { ok: false, err: 'stock:' + p.name };
      d = null; c.items.forEach(function(x){ if (x.pid === p.id) d = x; });
      if (d) d.q++; else c.items.push({ pid: p.id, name: p.name, price: p.price, cost: p.cost, q: 1 });
      p.qty--; return { ok: true };
    case 'com.dec':
      c = byId(St.comandas, o.cid); if (!c) return { ok: false, err: 'notfound' };
      for (i = 0; i < c.items.length; i++) if (c.items[i].pid === o.pid) {
        p = byId(St.products, o.pid); if (p) p.qty++;
        c.items[i].q--; if (c.items[i].q <= 0) c.items.splice(i, 1); break;
      }
      return { ok: true };
    case 'com.remove':
      c = byId(St.comandas, o.cid); if (!c) return { ok: false, err: 'notfound' };
      for (i = 0; i < c.items.length; i++) if (c.items[i].pid === o.pid) {
        p = byId(St.products, o.pid); if (p) p.qty += c.items[i].q;
        c.items.splice(i, 1); break;
      }
      return { ok: true };
    case 'com.close':
      c = byId(St.comandas, o.cid); if (!c) return { ok: false, err: 'notfound' };
      if (!c.items.length || PAYS.indexOf(o.pay) < 0) return { ok: false, err: 'invalid' };
      St.comandas = St.comandas.filter(function(x){ return x !== c; });
      return mkSale(St, env, 's' + c.id, o.pay, c.items.map(function(x){ return { pid: x.pid, name: x.name, price: x.price, cost: x.cost, q: x.q }; }), c.name);
    case 'com.cancel':
      c = byId(St.comandas, o.cid); if (!c) return { ok: false, err: 'notfound' };
      c.items.forEach(function(x){ var pp = byId(St.products, x.pid); if (pp) pp.qty += x.q; });
      St.comandas = St.comandas.filter(function(x){ return x !== c; }); return { ok: true };
    case 'sale.refund': {
      if (!adm) return { ok: false, err: 'role' };
      var sl = byId(St.sales, o.sid); if (!sl) return { ok: false, err: 'notfound' };
      sl.items.forEach(function(x){ var pp = byId(St.products, x.pid); if (pp) pp.qty += x.q; });
      St.sales = St.sales.filter(function(x){ return x !== sl; }); return { ok: true };
    }
    case 'sales.prune': {
      if (!adm) return { ok: false, err: 'role' };
      var b = Number(o.before) || 0, n0 = St.sales.length;
      St.sales = St.sales.filter(function(x){ return x.t >= b; }); return { ok: true, n: n0 - St.sales.length };
    }
  }
  return { ok: false, err: 'unknown' };
}
function errMsg(e){
  e = String(e || '');
  if (e.indexOf('stock:') === 0) return 'Sem estoque suficiente: ' + e.slice(6);
  return ({ role: 'Só o administrador pode fazer isso.', notfound: 'Item não encontrado (talvez outro celular já mexeu).', invalid: 'Dados inválidos.', auth: 'Este celular não tem mais acesso à adega.' })[e] || 'Não foi possível concluir.';
}

/* =====================================================================
   ENVIO DE OPERAÇÕES
   local: aplica na hora. LAN: manda ao servidor e espera voltar pela sincronização.
   ===================================================================== */
function dispatch(op){
  if (M.mode === 'local') {
    var r = reduce(S, { m: 'host', r: 'admin', ts: Date.now(), op: op });
    saveLocal(); sched(); return Promise.resolve(r);
  }
  return new Promise(function(res, rej){
    var id = 'o' + uid();
    pending[id] = { res: res, rej: rej, t: 0 };
    sendOp(id, JSON.stringify(op), 0);
  });
}
function sendOp(id, body, tries){
  api('/api/op?id=' + id, { method: 'POST', body: body }).then(function(r){
    var pd = pending[id]; if (!pd) return;
    if (r.status === 401) { delete pending[id]; pd.res({ ok: false, err: 'auth' }); revoked(); return; }
    if (!r.j || !r.j.ok) { delete pending[id]; pd.res({ ok: false, err: (r.j && r.j.err) || 'server' }); return; }
    pd.t = setTimeout(function(){ if (pending[id]) { delete pending[id]; pd.rej(new Error('timeout')); } }, 10000);
  }, function(){
    var pd = pending[id]; if (!pd) return;
    if (tries < 3) setTimeout(function(){ sendOp(id, body, tries + 1); }, 700 * (tries + 1));
    else { delete pending[id]; pd.rej(new Error('offline')); }
  });
}
var busy = false;
function act(op, ok, guard){
  if (guard) { if (busy) return; busy = true; }
  dispatch(op).then(function(r){
    busy = false;
    if (r && r.ok) { if (ok) ok(r); }
    else toast(errMsg(r && r.err));
    refreshAll();
  }, function(){ busy = false; toast('Sem conexão com a adega. Confira antes de repetir.'); });
}

function api(path, opt){
  opt = opt || {};
  var h = { 'X-Egua': '1' };
  if (M.token) h.Authorization = 'Bearer ' + M.token;
  var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null, to = 0;
  var init = { method: opt.method || 'GET', headers: h, cache: 'no-store' };
  if (opt.body != null) init.body = opt.body;
  if (ctl) { init.signal = ctl.signal; to = setTimeout(function(){ ctl.abort(); }, opt.timeout || 8000); if (opt.hold) opt.hold.abort = function(){ ctl.abort(); }; }
  return fetch(path, init).then(function(r){
    clearTimeout(to);
    return r.text().then(function(t){ var j = null; try { j = JSON.parse(t); } catch (e) {} return { status: r.status, j: j }; });
  }, function(e){ clearTimeout(to); throw e; });
}

/* ---------- sincronização (long-poll) ---------- */
function setOnline(v){ if (M.online !== v) { M.online = v; setSyncUI(); } }
function syncLoop(gen){
  if (gen !== M.gen) return;
  var hold = {}; M.hold = hold;
  api('/api/sync?since=' + M.seq + '&wait=20&epoch=' + encodeURIComponent(M.epoch), { timeout: 32000, hold: hold }).then(function(r){
    if (gen !== M.gen) return;
    if (r.status === 401) { revoked(); return; }
    if (!r.j || !r.j.ops) throw new Error('bad');
    setOnline(true); applySync(r.j); syncLoop(gen);
  }).catch(function(){ if (gen !== M.gen) return; setOnline(false); setTimeout(function(){ syncLoop(gen); }, 1500); });
}
function startSync(){ M.gen++; if (M.hold && M.hold.abort) { try { M.hold.abort(); } catch (e) {} } syncLoop(M.gen); }
function applySync(d){
  if (d.ver !== undefined) { if (M.ver === null) M.ver = d.ver; else if (d.ver !== M.ver) { location.reload(); return; } }
  var reset = !!d.reset || d.epoch !== M.epoch, n = 0;
  if (reset) { S = fromSnap(d.snapshot || ''); M.epoch = d.epoch; M.seq = d.snapSeq; }
  M.snapSeq = d.snapSeq; M.top = d.seq;
  d.ops.forEach(function(o){
    if (o.seq <= M.seq) return;
    var res; try { res = reduce(S, { m: o.m, r: o.r, ts: o.ts, op: JSON.parse(o.op) }); } catch (e) { res = { ok: false, err: 'bad' }; }
    M.seq = o.seq; n++;
    var pd = pending[o.id]; if (pd) { delete pending[o.id]; clearTimeout(pd.t); pd.res(res); }
  });
  if (reset || n) { if (M.ready) sched(); }
  maybeCompact();
}
function maybeCompact(){
  if (!M.host || M.compacting || M.seq - M.snapSeq < 150 || M.seq !== M.top) return;
  M.compacting = true;
  var seq = M.seq, body = JSON.stringify(S);
  api('/api/snapshot?seq=' + seq + '&epoch=' + encodeURIComponent(M.epoch), { method: 'POST', body: body, timeout: 20000 }).then(function(r){
    M.compacting = false; if (r.j && r.j.ok) M.snapSeq = seq;
  }, function(){ M.compacting = false; });
}
function revoked(){
  if (M.host) return;
  M.gen++; M.ready = false;
  try { localStorage.removeItem(TOKKEY); } catch (e) {}
  M.token = ''; cur = null; renderSheet(); $('#cartbar').hidden = true;
  gate('removed');
}
function pollInfo(){
  if (!M.host) return;
  api('/api/info').then(function(r){
    if (r.j && r.j.egua) {
      var chg = JSON.stringify(r.j.ips) !== JSON.stringify(M.ips);
      M.ips = r.j.ips || []; M.port = r.j.port; M.peers = r.j.peers || {};
      var ae = document.activeElement;
      if (M.ready && !cur && view === 'ajustes' && !(ae && ae.tagName === 'INPUT')) renderPage('ajustes');
      else if (cur && cur.t === 'dev' && chg) renderSheet();
    }
  }, function(){});
}
/* ---------- atualização do app (sem reinstalar o APK) ---------- */
function checkUpdate(manual){
  if (!M.host || M.mode !== 'lan') return;
  M.updAt = Date.now();
  return api('/api/update/check', { timeout: 15000 }).then(function(r){
    var j = r.j || {}; M.upd = j;
    if (j.ok && j.new) { cur = { t: 'upd' }; renderSheet(); }
    else if (manual) {
      if (j.ok && j.needApk) toast('Há versão nova, mas precisa instalar um APK novo.');
      else if (j.ok) toast('Você já está na versão mais recente (v' + j.cur + ').');
      else toast(j.err === 'noconfig' ? 'Digite o endereço do GitHub primeiro.' : 'Sem internet ou endereço errado.');
    }
    if (cur && cur.t === 'upd') renderSheet(); else if (view === 'ajustes' && !cur) renderPage('ajustes');
  }, function(){ if (manual) toast('Sem internet no momento.'); });
}
function applyUpdate(){
  if (busy) return; busy = true; toast('Baixando atualização…');
  api('/api/update/apply', { method: 'POST', timeout: 120000 }).then(function(r){
    busy = false; var j = r.j || {};
    if (j.ok) { toast('Atualizado! Reabrindo…'); setTimeout(function(){ location.reload(); }, 900); }
    else toast(({ net: 'Falha ao baixar. Confira a internet.', needapk: 'Precisa instalar um APK novo.', uptodate: 'Já está atualizado.', bad: 'Pacote de atualização inválido.', disk: 'Sem espaço para atualizar.' })[j.err] || 'Não consegui atualizar.');
  }, function(){ busy = false; toast('Falha ao baixar. Confira a internet.'); });
}
function inviteUrl(){
  var ip = M.ips[Math.min(M.ipSel, M.ips.length - 1)];
  return (ip && M.inv) ? 'http://' + ip + ':' + M.port + '/?j=' + M.inv.code : '';
}
function newInvite(role, revokeOld){
  var first = revokeOld ? api('/api/invites', { method: 'DELETE' }) : Promise.resolve();
  return first.then(function(){ return api('/api/invite?role=' + role, { method: 'POST' }); }).then(function(r){
    if (r.j && r.j.ok) { M.inv = r.j; if (cur && cur.t === 'dev') renderSheet(); }
  }, function(){ toast('Não consegui gerar o convite.'); });
}
function wipeTo(ns_){ // troca TODOS os dados (restaurar backup / apagar tudo)
  if (M.mode === 'local') { S = ns_; saveLocal(); cart = {}; lastToday = 0; sched(); return Promise.resolve(true); }
  return api('/api/reset', { method: 'POST', body: JSON.stringify(ns_), timeout: 20000 }).then(function(r){
    if (!(r.j && r.j.ok)) return false;
    cart = {}; lastToday = 0; startSync(); return true;
  }, function(){ return false; });
}

/* =====================================================================
   TELAS
   ===================================================================== */
function cats(){
  var m = {}; S.products.forEach(function(p){ if (p.cat) m[p.cat] = 1; });
  return Object.keys(m).sort(function(a, b){ return a.localeCompare(b, 'pt-BR'); });
}
function vendaView(){
  var cs = cats(); if (F.cat && cs.indexOf(F.cat) < 0) F.cat = '';
  var chips = '<div class="catrow" id="cats"><button class="chip" data-act="cat" data-v="" aria-pressed="' + (F.cat === '') + '">Todas</button>' +
    cs.map(function(c){ return '<button class="chip" data-act="cat" data-v="' + esc(c) + '" aria-pressed="' + (F.cat === c) + '">' + esc(c) + '</button>'; }).join('') + '</div>';
  return exNote() + '<div class="bar"><input id="q" type="search" placeholder="Buscar produto" autocomplete="off" value="' + esc(F.q) + '"></div>' + chips + '<div id="list" class="list">' + vendaList() + '</div>';
}
function vendaList(){
  if (!S.products.length) return empty('Nenhum produto cadastrado', isAdmin() ? 'Cadastre os produtos na aba Estoque para começar a vender.' : 'Peça ao administrador para cadastrar os produtos.');
  var q = norm(F.q);
  var items = S.products.filter(function(p){ return (!q || norm(p.name + ' ' + p.cat).indexOf(q) > -1) && (!F.cat || p.cat === F.cat); }).sort(function(a, b){ return a.name.localeCompare(b.name, 'pt-BR'); });
  if (!items.length) return empty('Nada encontrado', 'Tente outro nome.');
  return items.map(function(p, i){
    var n = cart[p.id] || 0, out = p.qty <= 0;
    return '<button class="row"' + rs(i) + ' data-act="cart-add" data-id="' + esc(p.id) + '"' + (out ? ' disabled' : '') + '>' + thumb(p) + '<span class="grow"><b>' + esc(p.name) + '</b><small>' + esc(p.cat) + ' · ' + (out ? 'esgotado' : p.qty + ' em estoque') + '</small></span>' + (n ? '<span class="badge">' + n + '</span>' : '') + '<span class="price">' + money(p.price) + '</span></button>';
  }).join('');
}

function comandasView(){
  var h = '<div class="toolbar"><h2>Comandas abertas</h2><button class="btn primary" data-act="c-new">+ Nova</button></div>';
  if (!S.comandas.length) return h + empty('Nenhuma comanda aberta', 'Toque em Nova para abrir uma por nome ou mesa.');
  return h + '<div class="list">' + S.comandas.slice().sort(function(a, b){ return a.t - b.t; }).map(function(c, i){
    var n = sum(c.items, function(x){ return x.q; });
    return '<button class="row"' + rs(i) + ' data-act="c-open" data-id="' + esc(c.id) + '" data-k="' + esc(c.id) + '" data-q="' + comTotal(c) + '"><span class="grow"><b>' + esc(c.name) + '</b><small>' + n + (n === 1 ? ' item' : ' itens') + ' · aberta às ' + hhmm(c.t) + (c.by && multi() ? ' · ' + esc(c.by) : '') + '</small></span><span class="price">' + money(comTotal(c)) + '</span></button>';
  }).join('') + '</div>';
}

function estoqueView(){
  var ad = isAdmin(), val = sum(S.products, function(p){ return p.qty * p.cost; });
  return exNote() +
    '<div class="stats"><div class="stat" style="--d:0"><b>' + S.products.length + '</b><span>Produtos</span></div><div class="stat" style="--d:1"><b>' + lowCount() + '</b><span>Em falta ou baixo</span></div>' +
    (ad ? '<div class="stat" style="--d:2"><b data-money="' + val + '">' + money(val) + '</b><span>Valor a custo</span></div>' : '') + '</div>' +
    '<div class="bar"><input id="q" type="search" placeholder="Buscar produto" autocomplete="off" value="' + esc(F.q) + '"></div>' +
    '<div class="toolbar" style="flex-wrap:nowrap"><div style="flex:1;min-width:0">' + seg('low', [['all', 'Todos'], ['low', 'Estoque baixo']], F.low ? 1 : 0) + '</div>' + (ad ? '<button class="btn primary" data-act="p-new">+ Produto</button>' : '') + '</div>' +
    '<div id="list" class="list">' + estoqueList() + '</div>';
}
function estoqueList(){
  if (!S.products.length) return empty('Nenhum produto', isAdmin() ? 'Toque em + Produto para cadastrar o primeiro.' : 'O administrador ainda não cadastrou produtos.');
  var q = norm(F.q), ad = isAdmin();
  var items = S.products.filter(function(p){ return (!q || norm(p.name + ' ' + p.cat).indexOf(q) > -1) && (!F.low || p.qty <= p.min); }).sort(function(a, b){ return a.name.localeCompare(b.name, 'pt-BR'); });
  if (!items.length) return empty('Nada encontrado', 'Ajuste a busca ou o filtro.');
  return items.map(function(p, i){
    var cls = p.qty <= 0 ? 'bad' : p.qty <= p.min ? 'warn' : 'ok', lbl = p.qty <= 0 ? ' · Zerado' : p.qty <= p.min ? ' · Baixo' : '';
    var sub = esc(p.cat) + (ad ? ' · custo ' + money(p.cost) : '') + ' · venda ' + money(p.price);
    var inner = thumb(p) + '<span class="grow"><b>' + esc(p.name) + '</b><small>' + sub + '</small></span><span class="pill ' + cls + '">' + p.qty + ' un' + lbl + '</span>';
    return ad ? '<button class="row"' + rs(i) + ' data-act="p-open" data-id="' + esc(p.id) + '" data-k="' + esc(p.id) + '" data-q="' + p.qty + '">' + inner + '</button>' : '<div class="row"' + rs(i) + ' data-k="' + esc(p.id) + '" data-q="' + p.qty + '">' + inner + '</div>';
  }).join('');
}

function caixaView(){
  var opts = [['today', 'Hoje'], ['7d', '7 dias'], ['all', 'Tudo']];
  var idx = 0; opts.forEach(function(o, i){ if (o[0] === F.range) idx = i; });
  if (!opts.some(function(o){ return o[0] === F.range; })) F.range = 'today';
  return seg('range', opts, idx) + '<div id="cx" style="margin-top:14px">' + caixaBody() + '</div>';
}
function caixaBody(){
  var ss = salesIn(F.range), tot = sum(ss, function(s){ return s.total; }), lucro = sum(ss, profit);
  var byPay = PAYS.map(function(p){ return '<div class="kv"><span>' + p + '</span><b>' + money(sum(ss.filter(function(s){ return s.pay === p; }), function(s){ return s.total; })) + '</b></div>'; }).join('');
  var rows = ss.length ? '<div class="list">' + ss.slice(0, 100).map(function(s, i){
    var names = s.items.map(function(x){ return x.q + '× ' + x.name; });
    var txt = names.slice(0, 2).join(', ') + (names.length > 2 ? ' +' + (names.length - 2) : '');
    return '<button class="row"' + rs(i) + ' data-act="sale-open" data-id="' + esc(s.id) + '" data-k="' + esc(s.id) + '" data-q="1"><span class="grow"><b>' + esc(txt) + '</b><small>' + dhm(s.t) + ' · ' + s.pay + (s.com ? ' · ' + esc(s.com) : '') + (s.by ? ' · ' + esc(s.by) : '') + '</small></span><span class="price">' + money(s.total) + '</span></button>';
  }).join('') + '</div>' : empty('Nenhuma venda neste período', 'As vendas e comandas fechadas aparecem aqui.');
  return '<div class="stats"><div class="stat" style="--d:0"><b data-money="' + tot + '">' + money(tot) + '</b><span>Vendido</span></div><div class="stat" style="--d:1"><b>' + ss.length + '</b><span>Vendas</span></div><div class="stat" style="--d:2"><b data-money="' + lucro + '">' + money(lucro) + '</b><span>Lucro estimado</span></div></div>' +
    '<div class="section" style="margin-top:6px"><h3>Por forma de pagamento</h3><div>' + byPay + '</div></div>' +
    '<div class="section"><h3>Vendas</h3>' + rows + '</div>';
}

/* ---------- painéis ---------- */
function head(t, sub){ return '<div class="sh-head"><div><h2>' + t + '</h2>' + (sub ? '<small>' + sub + '</small>' : '') + '</div><button class="x" data-act="close-sheet" aria-label="Fechar">×</button></div>'; }
function paySeg(){ return seg('pay', PAYS.map(function(p){ return [p, p]; }), PAYS.indexOf(pay)); }
function stepper(dec, inc, id, q){ return '<div class="qty"><button class="rnd" data-act="' + dec + '" data-id="' + esc(id) + '" aria-label="Diminuir">−</button><b>' + q + '</b><button class="rnd" data-act="' + inc + '" data-id="' + esc(id) + '" aria-label="Aumentar">+</button></div>'; }

function cartSheet(){
  var ls = cartLines();
  return head('Carrinho', cartCount() + (cartCount() === 1 ? ' item' : ' itens')) +
    ls.map(function(l){ return '<div class="line" data-k="' + esc(l.p.id) + '" data-q="' + l.q + '">' + thumb(l.p) + '<span class="grow"><b>' + esc(l.p.name) + '</b><small>' + money(l.p.price) + ' cada</small></span>' + stepper('cart-dec', 'cart-inc', l.p.id, l.q) + '</div>'; }).join('') +
    '<div class="total"><span>Total</span><span>' + money(cartTotal()) + '</span></div>' +
    '<div class="stack"><span class="lbl">Forma de pagamento</span>' + paySeg() +
    '<button class="btn primary block" data-act="cart-done">Finalizar venda</button>' +
    '<button class="btn block" data-act="cart-clear">Esvaziar carrinho</button></div>';
}
function cnewSheet(){
  return head('Nova comanda') + '<div class="form"><label>Nome ou mesa<input id="cname" placeholder="Ex.: Mesa 4, João" autocomplete="off"></label><button class="btn primary block" data-act="c-create">Abrir comanda</button></div>';
}
function comSheet(){
  var c = comById(cur.id), t = comTotal(c);
  if (cur.mode === 'pick') {
    return head('Adicionar item', esc(c.name) + ' · ' + money(t)) +
      '<div class="bar"><input id="qp" type="search" placeholder="Buscar produto" autocomplete="off" value="' + esc(F.qp) + '"></div>' +
      '<div id="plist" class="list">' + pickList() + '</div>' +
      '<div class="stack"><button class="btn primary block" data-act="c-back">Concluído</button></div>';
  }
  var lines = c.items.length ? c.items.map(function(i){ return '<div class="line" data-k="' + esc(i.pid) + '" data-q="' + i.q + '">' + thumb(Pr(i.pid)) + '<span class="grow"><b>' + esc(i.name) + '</b><small>' + money(i.price) + ' cada · ' + money(i.price * i.q) + '</small></span>' + stepper('c-dec', 'c-inc', i.pid, i.q) + '<button class="rnd del" data-act="c-rm" data-id="' + esc(i.pid) + '" aria-label="Remover item da comanda"><svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3"/></svg></button></div>'; }).join('') : empty('Comanda vazia', 'Toque em Adicionar item.');
  return head(esc(c.name), 'Aberta às ' + hhmm(c.t) + (c.by && multi() ? ' por ' + esc(c.by) : '')) + lines +
    '<div class="total"><span>Total</span><span>' + money(t) + '</span></div>' +
    '<div class="stack"><button class="btn block" data-act="c-pick">+ Adicionar item</button>' +
    (c.items.length ? '<span class="lbl">Forma de pagamento</span>' + paySeg() + '<button class="btn primary block" data-act="c-close">Fechar e receber</button>' : '') +
    '<button class="btn danger block" data-act="c-cancel">Cancelar comanda</button></div>';
}
function pickList(){
  var c = comById(cur.id), q = norm(F.qp);
  var items = S.products.filter(function(p){ return !q || norm(p.name + ' ' + p.cat).indexOf(q) > -1; }).sort(function(a, b){ return a.name.localeCompare(b.name, 'pt-BR'); });
  if (!items.length) return empty('Nada encontrado', 'Tente outro nome.');
  return items.map(function(p){
    var n = 0; c.items.forEach(function(i){ if (i.pid === p.id) n = i.q; });
    var out = p.qty <= 0;
    return '<button class="row" data-act="c-add" data-id="' + esc(p.id) + '" data-k="' + esc(p.id) + '" data-q="' + n + '"' + (out ? ' disabled' : '') + '>' + thumb(p) + '<span class="grow"><b>' + esc(p.name) + '</b><small>' + (out ? 'esgotado' : p.qty + ' em estoque') + '</small></span>' + (n ? '<span class="rnd mini" role="button" data-act="c-dec" data-id="' + esc(p.id) + '" aria-label="Tirar um da comanda">−</span><span class="badge">' + n + '</span>' : '') + '<span class="price">' + money(p.price) + '</span></button>';
  }).join('');
}
function prodSheet(){
  var p = cur.id ? Pr(cur.id) : { name: '', cat: '', price: 0, cost: 0, qty: 0, min: 0 }, dr = cur.draft || {};
  var v = function(k, d){ return dr[k] !== undefined ? dr[k] : d; };
  var cm = { Cerveja: 1, Vinho: 1, Destilado: 1, Espumante: 1, Refrigerante: 1, Outros: 1 };
  S.products.forEach(function(x){ if (x.cat) cm[x.cat] = 1; });
  var pu = cur.pend !== undefined ? cur.pend : photoUrl(p);
  return head(cur.id ? 'Editar produto' : 'Novo produto') + '<div class="form">' +
    '<div class="phrow"><span class="phbox">' + (pu ? '<img alt="Foto do produto" src="' + esc(pu) + '">' : LOGO) + '</span><div class="stack">' +
    '<label class="btn">Tirar foto<input id="ph-cam" type="file" accept="image/*" capture="environment" hidden></label>' +
    '<label class="btn">Escolher da galeria<input id="ph-gal" type="file" accept="image/*" hidden></label>' +
    (pu ? '<button class="btn danger" data-act="ph-rm">Remover foto</button>' : '') + '</div></div>' +
    '<label>Nome<input id="f-name" value="' + esc(v('name', p.name)) + '" autocomplete="off"></label>' +
    '<label>Categoria<input id="f-cat" list="cats-dl" value="' + esc(v('cat', p.cat)) + '" autocomplete="off"><datalist id="cats-dl">' + Object.keys(cm).map(function(c){ return '<option value="' + esc(c) + '">'; }).join('') + '</datalist></label>' +
    '<div class="grid2"><label>Preço de venda (R$)<input id="f-price" inputmode="decimal" placeholder="0,00" value="' + esc(v('price', p.price ? fm(p.price) : '')) + '"></label><label>Preço de custo (R$)<input id="f-cost" inputmode="decimal" placeholder="0,00" value="' + esc(v('cost', p.cost ? fm(p.cost) : '')) + '"></label></div>' +
    '<div class="grid2"><label>Quantidade em estoque<input id="f-qty" type="number" inputmode="numeric" min="0" value="' + esc(v('qty', p.qty)) + '"></label><label>Avisar quando chegar em<input id="f-min" type="number" inputmode="numeric" min="0" value="' + esc(v('min', p.min)) + '"></label></div>' +
    '<div class="chips"><span class="lbl">Entrada rápida</span><button class="chip" data-act="p-plus" data-n="6">+6</button><button class="chip" data-act="p-plus" data-n="12">+12</button><button class="chip" data-act="p-plus" data-n="24">+24</button></div>' +
    '<button class="btn primary block" data-act="p-save">Salvar</button>' +
    (cur.id ? '<button class="btn danger block" data-act="p-del">Excluir produto</button>' : '') + '</div>';
}
function photoSheet(){
  var p = Pr(cur.id);
  return head(esc(p.name), esc(p.cat) + ' · ' + money(p.price)) + '<div class="bigph"><img alt="Foto de ' + esc(p.name) + '" src="' + esc(photoUrl(p)) + '"></div>' +
    '<div class="stack"><button class="btn block" data-act="close-sheet">Voltar</button></div>';
}
var RESET_PW = '24032003';
function pwSheet(){
  return head('Apagar todos os dados', 'Isso apaga produtos, vendas e comandas') + '<div class="form"><p style="margin:0">Digite a senha para continuar. Esta ação não pode ser desfeita (faça um backup antes).</p>' +
    '<label>Senha<input id="pw-in" type="password" inputmode="numeric" autocomplete="off"></label>' +
    '<button class="btn danger block" data-act="pw-ok">Apagar tudo</button></div>';
}
function confirmReset(){
  var el = $('#pw-in'); if (!el) return;
  if (el.value !== RESET_PW) { toast('Senha incorreta'); el.value = ''; el.focus(); return; }
  closeSheet(); resetAll();
}
function lowSheet(){
  var ls = S.products.filter(function(p){ return p.qty <= p.min; }).sort(function(a, b){ return a.qty - b.qty; });
  return head('Estoque acabando', ls.length + (ls.length === 1 ? ' produto precisa' : ' produtos precisam') + ' de reposição') +
    '<div class="list">' + ls.slice(0, 40).map(function(p){
      var cls = p.qty <= 0 ? 'bad' : 'warn';
      return '<div class="row">' + thumb(p) + '<span class="grow"><b>' + esc(p.name) + '</b><small>Avisar em ' + p.min + ' un</small></span><span class="pill ' + cls + '">' + (p.qty <= 0 ? 'Zerado' : p.qty + ' un') + '</span></div>';
    }).join('') + (ls.length > 40 ? '<small>E mais ' + (ls.length - 40) + '…</small>' : '') + '</div>' +
    '<div class="stack"><button class="btn primary block" data-act="low-go">Ver no estoque</button><button class="btn block" data-act="close-sheet">Fechar</button></div>';
}
function lowAlert(){
  if (M.lowShown || !isAdmin() || cur || !S.products.some(function(p){ return p.qty <= p.min; })) return;
  M.lowShown = true; cur = { t: 'low' }; renderSheet();
}
function removeLine(pid, fn){
  var el = document.querySelector('#panel .line[data-k="' + pid + '"]');
  if (el && animOn()) { el.classList.add('out'); setTimeout(fn, 230); } else fn();
}
function stashDraft(){
  cur.draft = { name: $('#f-name').value, cat: $('#f-cat').value, price: $('#f-price').value, cost: $('#f-cost').value, qty: $('#f-qty').value, min: $('#f-min').value };
}
function saleSheet(){
  var s = saleById(cur.id);
  return head('Venda de ' + money(s.total), dhm(s.t) + ' · ' + s.pay + (s.com ? ' · ' + esc(s.com) : '') + (s.by ? ' · vendedor ' + esc(s.by) : '')) +
    s.items.map(function(i){ return '<div class="kv"><span>' + i.q + '× ' + esc(i.name) + '</span><b>' + money(i.price * i.q) + '</b></div>'; }).join('') +
    '<div class="kv"><span>Lucro estimado</span><b>' + money(profit(s)) + '</b></div>' +
    '<div class="stack"><button class="btn danger block" data-act="sale-refund">Estornar venda e devolver ao estoque</button></div>';
}
function bkTextSheet(){
  return head('Copiar') + '<div class="form"><small>Seu aparelho não deixou copiar sozinho. Segure no texto, selecione tudo, copie e guarde.</small><textarea id="bk-out" readonly>' + esc(cur.txt) + '</textarea></div>';
}
function bkInSheet(){
  return head('Restaurar backup') + '<div class="form"><small>Cole aqui o texto do backup. Isso substitui todos os dados atuais.</small><textarea id="bk-in" placeholder="Cole o backup aqui"></textarea><button class="btn danger block" data-act="bk-restore">Restaurar e substituir tudo</button></div>';
}

/* anima só o que mudou: linha nova entra, número que mudou dá um "pulo" */
function snapKeys(root){ var m = {}; if (root) root.querySelectorAll('[data-k]').forEach(function(e){ m[e.dataset.k] = e.dataset.q; }); return m; }
function flagDiff(root, prev){
  if (!prev || !root || !animOn()) return;
  root.querySelectorAll('[data-k]').forEach(function(e){
    var k = e.dataset.k;
    if (!(k in prev)) e.classList.add('new');
    else if (prev[k] !== e.dataset.q) { var b = e.querySelector('.qty b, .badge, .pill, .price'); if (b) b.classList.add('bump'); }
  });
}
function renderSheet(){
  if (cur && ((cur.t === 'com' && !comById(cur.id)) || (cur.t === 'prod' && cur.id && !Pr(cur.id)) || (cur.t === 'sale' && !saleById(cur.id)) || (cur.t === 'photo' && !photoUrl(Pr(cur.id))) || (cur.t === 'cart' && !cartCount()))) cur = null;
  var sheet = $('#sheet'), panel = $('#panel');
  if (!cur) { sheet.hidden = true; panel.innerHTML = ''; document.body.classList.remove('lock'); lastKey = ''; return; }
  var key = cur.t + '|' + (cur.id || '') + '|' + (cur.mode || ''), same = key === lastKey, st = same ? panel.scrollTop : 0;
  var h = '';
  if (cur.t === 'cart') h = cartSheet();
  else if (cur.t === 'cnew') h = cnewSheet();
  else if (cur.t === 'com') h = comSheet();
  else if (cur.t === 'prod') h = prodSheet();
  else if (cur.t === 'photo') h = photoSheet();
  else if (cur.t === 'pw') h = pwSheet();
  else if (cur.t === 'low') h = lowSheet();
  else if (cur.t === 'sale') h = saleSheet();
  else if (cur.t === 'prof') h = profSheet();
  else if (cur.t === 'dev') h = devSheet();
  else if (cur.t === 'upd') h = updSheet();
  else if (cur.t === 'bk-text') h = bkTextSheet();
  else if (cur.t === 'bk-in') h = bkInSheet();
  var pk = same ? snapKeys(panel) : null, ptot = same ? ((panel.querySelector('.total span:last-child') || {}).textContent || '') : '';
  panel.innerHTML = h;
  flagDiff(panel, pk);
  if (pk && animOn()) { var tt = panel.querySelector('.total span:last-child'); if (tt && ptot && tt.textContent !== ptot) tt.classList.add('bump'); }
  if (sheet.hidden || !same) sheet.hidden = false;
  document.body.classList.add('lock'); panel.scrollTop = st; lastKey = key;
  if (!same) {
    var f = cur.t === 'cnew' ? '#cname' : (cur.t === 'prod' && !cur.id) ? '#f-name' : cur.t === 'bk-text' ? '#bk-out' : cur.t === 'pw' ? '#pw-in' : null;
    if (f) { var el = $(f); if (el) { el.focus(); if (cur.t === 'bk-text') el.select(); } }
  }
}
function closeSheet(){ if (cur && cur.t === 'photo' && cur.prev) { cur = cur.prev; renderSheet(); return; } cur = null; armed = null; renderSheet(); }

/* ---------- cabeçalho, abas e carrossel ---------- */
function cartbar(){
  var n = view === 'venda' ? cartCount() : 0, b = $('#cartbar');
  b.hidden = !n;
  if (n) { $('#cb-l').textContent = n + (n === 1 ? ' item no carrinho' : ' itens no carrinho'); $('#cb-r').textContent = money(cartTotal()); }
}
function hdr(){
  var h = new Date().getHours();
  var g = h < 5 ? 'Boa noite' : h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  $('#brand').textContent = adegaName();
  $('#greet').textContent = g + ', ' + userName();
  $('#avatar').textContent = (userName() || '?').trim().charAt(0).toUpperCase();
  if (isAdmin()) {
    var td = salesIn('today'), tot = sum(td, function(s){ return s.total; });
    $('#t-l1').textContent = 'Vendido hoje'; $('#t-l2').textContent = 'vendas';
    $('#today-n').textContent = td.length;
    tween($('#today-v'), tot, lastToday); lastToday = tot;
  } else {
    $('#t-l1').textContent = 'Comandas abertas'; $('#t-l2').textContent = 'itens em falta';
    $('#today-v').textContent = S.comandas.length; $('#today-n').textContent = lowCount();
  }
  setSyncUI();
}
function buildShell(){
  VIEWS = isAdmin() ? ['comandas', 'venda', 'estoque', 'caixa', 'ajustes'] : ['comandas', 'venda', 'estoque', 'ajustes'];
  if (VIEWS.indexOf(view) < 0) view = 'venda';
  $('#track').innerHTML = VIEWS.map(function(v){ return '<section class="page" data-v="' + v + '"></section>'; }).join('');
  var tin = $('#tabsin');
  tin.querySelectorAll('button').forEach(function(b){ b.remove(); });
  VIEWS.forEach(function(v){
    var b = document.createElement('button');
    b.setAttribute('data-act', 'tab'); b.setAttribute('data-v', v); b.innerHTML = ICONS[v] + LABELS[v];
    tin.appendChild(b);
  });
  tin.style.setProperty('--n', VIEWS.length);
  var vi = VIEWS.indexOf(view);
  tin.style.setProperty('--i', vi); $('#track').style.setProperty('--vi', vi);
  pageEl(view).classList.add('on', 'enter');
  setTimeout(function(){ var p = pageEl(view); if (p) p.classList.remove('enter'); }, 900);
}
function tabsState(){ document.querySelectorAll('#tabs button').forEach(function(b){ b.setAttribute('aria-current', b.dataset.v === view ? 'page' : 'false'); }); }
function renderPage(v){ pageEl(v).innerHTML = ({ venda: vendaView, comandas: comandasView, estoque: estoqueView, caixa: caixaView, ajustes: ajustesView })[v](); }
function render(){ armed = null; tabsState(); hdr(); renderPage(view); cartbar(); }
function refreshAll(){ render(); renderSheet(); }
function settle(){ VIEWS.forEach(function(v){ var p = pageEl(v); p.classList.remove('moving', 'enter'); if (v !== view) p.innerHTML = ''; }); }
function go(v){
  var ni = VIEWS.indexOf(v), oi = VIEWS.indexOf(view);
  if (ni < 0) return;
  if (ni === oi) { window.scrollTo(0, 0); return; }
  var lo = Math.min(ni, oi), hi = Math.max(ni, oi), on = animOn();
  armed = null; view = v; F.q = '';
  window.scrollTo(0, 0);
  for (var i = lo; i <= hi; i++) { pageEl(VIEWS[i]).classList.add('moving'); renderPage(VIEWS[i]); }
  VIEWS.forEach(function(x){ pageEl(x).classList.toggle('on', x === v); });
  pageEl(v).classList.add('enter');
  $('#track').style.setProperty('--vi', ni);
  $('#tabsin').style.setProperty('--i', ni);
  tabsState(); cartbar(); tweenAll(pageEl(v));
  clearTimeout(go.t);
  if (on) go.t = setTimeout(settle, 560); else settle();
}

/* atualização quando chegam dados da nuvem (sem atrapalhar quem está digitando) */
function sched(){ clearTimeout(sched.t); sched.t = setTimeout(onData, 40); }
function onData(){
  if (!M.ready) return;
  hdr(); cartbar();
  var ae = document.activeElement, typing = ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA'), pg = pageEl(view);
  if (pg) {
    if (typing && pg.contains(ae)) { var l = A('#list'); if (l && (view === 'venda' || view === 'estoque')) l.innerHTML = view === 'venda' ? vendaList() : estoqueList(); }
    else { var st = window.scrollY, pv = snapKeys(pg); renderPage(view); flagDiff(pg, pv); window.scrollTo(0, st); }
  }
  if (cur) {
    var panel = $('#panel'), typingIn = typing && panel.contains(ae);
    if (typingIn) { if (cur.t === 'com' && cur.mode === 'pick') { var pl = $('#plist'); if (pl) pl.innerHTML = pickList(); } }
    else if (['cart', 'com', 'sale', 'dev'].indexOf(cur.t) > -1) renderSheet();
  }
}

function setSyncUI(){
  var el = $('#sync');
  if (M.mode !== 'lan') { el.hidden = true; return; }
  el.hidden = false;
  el.className = 'sync ' + (M.online ? 'ok' : 'off');
  el.textContent = M.online ? (M.host ? 'Servidor ligado' : 'Conectado à adega') : (M.host ? 'Servidor com problema…' : 'Sem conexão · tentando de novo');
}

function ajustesView(){
  var ti = { auto: 0, light: 1, dark: 2 }[P.theme] || 0, ad = isAdmin();
  var h = '<div class="profile"><div class="avatar big">' + esc((userName() || '?').trim().charAt(0).toUpperCase()) + '</div>' +
    '<div class="grow"><span class="pname">' + esc(userName()) + '</span><span class="role">' + (ad ? 'Administrador' : 'Atendente') + '</span><small>' + esc(adegaName()) + '</small></div>' +
    '<button class="btn" data-act="prof-edit">Editar</button></div>';

  if (M.mode === 'local') {
    h += '<div class="section"><h3>Dispositivos</h3><small>Nesta versão os dados ficam só neste celular. Para outros celulares usarem a mesma adega, use o app instalado (APK).</small>' +
      '<button class="btn primary block" data-act="dev-open">Conectar Dispositivos Extras</button></div>';
  } else if (M.host) {
    var others = S.members.filter(function(m){ return m.id !== 'host'; }), addr = M.ips.length ? 'http://' + M.ips[0] + ':' + M.port : '';
    h += '<div class="section"><h3>Servidor da adega</h3>' +
      '<small>Este celular guarda todos os dados e entrega o app para os outros pelo Wi-Fi. O servidor fica ligado em segundo plano (notificação fixa), mesmo com o app fechado. Deixe este aparelho ligado, carregando e no Wi-Fi.</small>' +
      (addr ? '<div class="linkbox">' + esc(addr) + '</div>' : '<small>Sem Wi-Fi no momento. Conecte este celular a uma rede (ou ligue o roteador portátil) para os outros entrarem.</small>') + '</div>' +
      '<div class="section"><h3>Dispositivos conectados</h3>' +
      '<div class="dev"><span class="grow"><b>' + esc(userName()) + ' (este celular)</b><small>Administrador · servidor</small></span></div>' +
      others.map(function(m){
        var age = M.peers[m.id], on = age !== undefined && age < 40;
        return '<div class="dev"><span class="grow"><b>' + esc(m.name || 'Sem nome') + '</b><small>' + (m.role === 'admin' ? 'Administrador' : 'Atendente') + ' · <span class="sync ' + (on ? 'ok' : 'off') + '" style="margin:0">' + (on ? 'online' : 'offline') + '</span></small></span><button class="btn danger" data-act="m-del" data-id="' + esc(m.id) + '">Remover</button></div>';
      }).join('') + (others.length ? '' : '<small>Nenhum outro celular conectado ainda.</small>') +
      '<button class="btn primary block" data-act="dev-open">Conectar Dispositivos Extras</button></div>';
  } else {
    h += '<div class="section"><h3>Conexão</h3><small>Este celular está conectado à adega ' + esc(adegaName()) + ' pelo Wi-Fi. Tudo que você lança aparece nos outros aparelhos.</small></div>';
  }

  if (M.mode === 'lan' && M.host) {
    h += '<div class="section"><h3>Atualização do app</h3><small>Versão instalada: v' + esc(M.ver === null ? '?' : M.ver) + '. Com internet, o app procura versão nova sempre que abre. Endereço do projeto no GitHub (usuario/repositorio, público):</small>' +
      '<label><input id="upd-repo" value="' + esc((M.upd && M.upd.repo) || '') + '" placeholder="usuario/repositorio" autocapitalize="off" autocomplete="off" spellcheck="false"></label>' +
      '<div class="chips"><button class="btn" data-act="upd-save">Salvar endereço</button><button class="btn" data-act="upd-check">Procurar atualização</button></div></div>';
  }
  h += '<div class="section"><h3>Temas do Aplicativo</h3>' + skinPicker() + '<small>Vale só para este aparelho. Os temas seguem o claro/escuro do celular; o Neve é sempre claro.</small></div>' +
    '' +
    '<div class="section"><h3>Animações</h3>' + seg('anim', [['on', 'Ligadas'], ['auto', 'Seguir o aparelho']], P.anim === 'auto' ? 1 : 0) + '<small>Se o seu celular estiver com "remover animações" ativado, escolha Ligadas para ver as telas deslizando.</small></div>' +
    '<div class="section"><h3>Assistente ADEGA</h3>' + seg('chat', [['on', 'Ligada'], ['off', 'Desligada']], P.chat === 'off' ? 1 : 0) + '<small>O chat do topo que ajuda com estoque, vendas e comandas. Vale só para este aparelho.</small></div>';

  if (M.host || M.mode === 'local') {
    h += '<div class="section"><h3>Backup dos dados</h3><small>Os dados ficam salvos neste celular. Copie o backup de vez em quando e guarde em lugar seguro, por exemplo mandando para você no WhatsApp.</small>' +
      '<div class="chips"><button class="btn" data-act="bk-copy">Copiar backup</button><button class="btn" data-act="bk-open">Restaurar backup</button></div>' +
      '<button class="btn block" data-act="prune">Limpar vendas com mais de 120 dias</button></div>' +
      '<div class="section"><h3>Zona de perigo</h3><button class="btn danger block" data-act="reset">Apagar todos os dados</button></div>';
  }
  if (!M.host && M.mode === 'lan') h += '<div class="section"><button class="btn block" data-act="leave">Sair desta adega neste celular</button></div>';
  return h + '<small class="about">' + esc(adegaName()) + ' · versão 2.0</small>';
}

function profSheet(){
  return head('Editar perfil') + '<div class="form">' +
    '<label>Seu nome<input id="pf-user" value="' + esc(userName()) + '" autocomplete="off"></label>' +
    (isAdmin() ? '<label>Nome da adega<input id="pf-adega" value="' + esc(adegaName()) + '" autocomplete="off"></label>' : '') +
    '<div><span class="lbl">Função</span><br><span class="role">' + (isAdmin() ? 'Administrador' : 'Atendente') + '</span></div>' +
    '<button class="btn primary block" data-act="prof-save">Salvar</button></div>';
}

function updSheet(){
  var u = M.upd || {};
  return head('Atualização disponível', 'Versão ' + u.cur + ' para ' + u.latest) + '<div class="form"><p style="margin:0">Tem uma versão nova do app. Atualizar leva alguns segundos e o app reabre sozinho. Os outros celulares atualizam junto. Seus dados não mudam.</p>' +
    '<button class="btn primary block" data-act="upd-go">Atualizar agora</button><button class="btn block" data-act="close-sheet">Depois</button></div>';
}
function devSheet(){
  if (M.mode === 'local') {
    return head('Conectar Dispositivos Extras') + '<div class="form"><p style="margin:0">Esta versão é só a página (HTML): ela não consegue virar servidor. No <b>app instalado (APK)</b> o próprio celular da adega vira o servidor e gera o QR code.</p>' +
      '<ol class="steps"><li>Instale o APK no celular da adega.</li><li>Conecte os celulares ao mesmo Wi-Fi.</li><li>Abra Ajustes, Conectar Dispositivos Extras e escaneie o QR.</li></ol>' +
      '<small>Enquanto isso, o app continua funcionando normalmente neste aparelho.</small></div>';
  }
  if (!M.ips.length) {
    return head('Conectar Dispositivos Extras') + '<div class="form"><p style="margin:0">Este celular não está em nenhuma rede Wi-Fi. Conecte-o ao Wi-Fi da adega, ou ligue o <b>roteador portátil</b> (hotspot) e conecte os outros nele. Depois abra esta tela de novo.</p></div>';
  }
  var url = inviteUrl(), role = M.inv ? M.inv.role : 'staff';
  return head('Conectar Dispositivos Extras', 'Aponte a câmera do outro celular para o QR') +
    '<div class="form">' + seg('invrole', [['staff', 'Atendente'], ['admin', 'Administrador']], role === 'admin' ? 1 : 0) +
    (url ? '<div class="qrbox" role="img" aria-label="QR code do convite">' + qrSvg(url) + '</div>' : '<small>Gerando o convite…</small>') +
    '<small>' + (role === 'admin' ? 'Administrador vê tudo: custos, lucro e pode editar produtos.' : 'Atendente abre comandas, lança vendas e consulta o estoque. Não vê custos nem lucro.') +
    ' O outro celular precisa estar <b>no mesmo Wi-Fi</b> e este app precisa ficar aberto. Não precisa instalar nada.</small>' +
    (url ? '<div class="linkbox">' + esc(url) + '</div>' : '') +
    (M.ips.length > 1 ? '<div class="chips"><span class="lbl">Endereço</span>' + M.ips.map(function(ip, i){ return '<button class="chip" data-act="ip-pick" data-i="' + i + '" aria-pressed="' + (i === M.ipSel) + '">' + esc(ip) + '</button>'; }).join('') + '</div>' : '') +
    '<div class="chips"><button class="btn" data-act="inv-copy">Copiar link</button><button class="btn" data-act="inv-share">Compartilhar</button></div>' +
    '<button class="btn danger block" data-act="inv-regen">Gerar novo convite (o QR antigo para de valer)</button></div>';
}

/* ---------- telas de entrada (celular convidado) ---------- */
var gateBusy = false, JOINCODE = '';
function gate(name, d){
  d = d || {};
  var g = $('#gate'), h = '', logo = '<div class="g-logo">' + LOGO + '</div>';
  var err = d.err ? '<div class="err" role="alert">' + esc(d.err) + '</div>' : '';
  if (name === 'join') {
    h = logo + '<h2>Entrar na adega</h2><p>Você foi convidado. Digite seu nome para aparecer nas comandas e vendas.</p>' + err +
      '<div class="form"><label>Seu nome<input id="g-user" value="' + esc(d.user || '') + '" autocomplete="given-name"></label>' +
      '<button class="btn primary block" data-act="g-join"' + (gateBusy ? ' disabled' : '') + '>' + (gateBusy ? 'Entrando…' : 'Entrar na adega') + '</button></div>';
  } else if (name === 'needinvite') {
    h = logo + '<h2>Falta o convite</h2><p>' + esc(d.msg || 'Peça para o administrador abrir Ajustes, Conectar Dispositivos Extras, e escaneie o QR code com a câmera deste celular.') + '</p>';
  } else if (name === 'removed') {
    h = logo + '<h2>Acesso encerrado</h2><p>Este celular não faz mais parte da adega. Peça um novo QR code ao administrador.</p>';
  }
  g.innerHTML = '<div class="g-in">' + h + '</div>';
  g.hidden = false; g.dataset.name = name;
  document.body.classList.add('lock');
  var f = g.querySelector('input'); if (f && !f.value) { try { f.focus(); } catch (e) {} }
}
function gateClose(){ var g = $('#gate'); g.hidden = true; g.innerHTML = ''; document.body.classList.remove('lock'); }
function gv(id){ var e = $('#' + id); return e ? e.value.trim() : ''; }
function doJoin(){
  var nm = gv('g-user');
  if (!nm) { gate('join', { err: 'Digite seu nome.' }); return; }
  gateBusy = true; gate('join', { user: nm });
  fetch('/api/join?code=' + encodeURIComponent(JOINCODE), { method: 'POST', headers: { 'X-Egua': '1' }, body: nm })
    .then(function(r){ return r.json(); })
    .then(function(j){
      gateBusy = false;
      if (!j.ok) { gate('join', { user: nm, err: j.err === 'throttle' ? 'Muitas tentativas. Espere um minuto.' : 'Convite inválido ou vencido. Peça um QR novo ao administrador.' }); return; }
      try { localStorage.setItem(TOKKEY, j.token); } catch (e) {}
      M.token = j.token; M.id = j.id; M.role = j.role;
      try { history.replaceState(null, '', location.pathname); } catch (e) {}
      gateClose(); startLan();
    }, function(){ gateBusy = false; gate('join', { user: nm, err: 'Não consegui falar com o celular da adega. Confira se está no mesmo Wi-Fi.' }); });
}

/* =====================================================================
   AÇÕES DA TELA
   ===================================================================== */
function finishSale(){
  var ls = cartLines(); if (!ls.length) return;
  for (var i = 0; i < ls.length; i++) if (ls[i].q > ls[i].p.qty) { toast('Estoque mudou: ' + ls[i].p.name); return; }
  act({ t: 'sale.create', sid: uid(), pay: pay, lines: ls.map(function(l){ return { pid: l.p.id, q: l.q }; }) }, function(r){
    cart = {}; closeSheet(); toast('Venda registrada: ' + money(r.total));
  }, true);
}
function createCom(){
  var n = ($('#cname').value || '').trim(), cid = uid();
  act({ t: 'com.new', cid: cid, name: n }, function(){ cur = { t: 'com', id: cid, mode: 'pick' }; F.qp = ''; }, true);
}
function closeCom(){
  var c = comById(cur.id); if (!c || !c.items.length) { toast('Adicione itens antes de fechar'); return; }
  act({ t: 'com.close', cid: cur.id, pay: pay }, function(r){ closeSheet(); toast('Comanda fechada: ' + money(r.total)); }, true);
}
function saveProd(){
  var name = $('#f-name').value.trim(), price = pm($('#f-price').value);
  if (!name) { toast('Digite o nome do produto'); return; }
  if (price <= 0) { toast('Digite o preço de venda'); return; }
  var d = { name: name, cat: $('#f-cat').value.trim() || 'Outros', price: price, cost: pm($('#f-cost').value), qty: Math.max(0, parseInt($('#f-qty').value, 10) || 0), min: Math.max(0, parseInt($('#f-min').value, 10) || 0) };
  var pid = cur.id || uid(), pend = cur.pend;
  act({ t: 'product.save', pid: pid, d: d }, function(){ closeSheet(); toast('Produto salvo'); if (pend !== undefined) savePhoto(pid, pend); }, true);
}
function saveProf(){
  var u = $('#pf-user').value.trim(), a = $('#pf-adega') ? $('#pf-adega').value.trim() : '';
  if (!u) { toast('Digite seu nome'); return; }
  act({ t: 'member.rename', name: u }, function(){
    if (a && a !== adegaName()) dispatch({ t: 'adega.rename', name: a }).then(function(){ refreshAll(); });
    closeSheet(); toast('Perfil atualizado');
  }, true);
}
function backupText(){ return JSON.stringify({ v: 1, adega: S.adega, cc: S.cc, products: S.products, comandas: S.comandas, sales: S.sales }); }
function restore(){
  var o;
  try { o = JSON.parse($('#bk-in').value); } catch (e) { toast('Texto de backup inválido'); return; }
  if (!validBackup(o)) { toast('Texto de backup inválido'); return; }
  var n = normalize(o); n.members = S.members.slice(); n.adega = o.adega || S.adega;
  n.products.forEach(function(x){ if (M.mode === 'lan') delete x.imgData; else delete x.img; });
  wipeTo(n).then(function(ok){ closeSheet(); render(); toast(ok ? 'Backup restaurado' : 'Não consegui restaurar'); });
}
function resetAll(){
  var n = emptyState(); n.members = S.members.slice(); n.adega = S.adega; n.seeded = true;
  wipeTo(n).then(function(ok){ render(); toast(ok ? 'Dados apagados' : 'Não consegui apagar'); });
}
function onSeg(id, v){
  if (id === 'pay') pay = v;
  else if (id === 'range') { F.range = v; var cx = A('#cx'); cx.innerHTML = caixaBody(); tweenAll(cx); cx.classList.remove('enter'); void cx.offsetWidth; cx.classList.add('enter'); clearTimeout(onSeg.t); onSeg.t = setTimeout(function(){ cx.classList.remove('enter'); }, 700); }
  else if (id === 'low') { F.low = (v === 'low'); A('#list').innerHTML = estoqueList(); }
  else if (id === 'theme') { P.theme = v; applyTheme(); savePrefs(); }
  else if (id === 'anim') { P.anim = v; applyAnim(); savePrefs(); }
  else if (id === 'chat') { P.chat = v; applyChat(); savePrefs(); toast(v === 'on' ? 'Assistente ligada' : 'Assistente desligada'); }
  else if (id === 'invrole') { M.inv = null; renderSheet(); newInvite(v, true); }
}
function bump(id){
  var row = A('#list [data-id="' + id + '"]'); if (!row) return;
  var b = row.querySelector('.badge');
  if (!b) { b = document.createElement('span'); b.className = 'badge'; row.insertBefore(b, row.querySelector('.price')); }
  b.textContent = cart[id]; b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
}
function shareInvite(){
  var u = inviteUrl(); if (!u) return;
  if (navigator.share) navigator.share({ title: 'Égua da Cachaça', text: 'Entre na adega ' + adegaName() + ' (mesmo Wi-Fi)', url: u }).catch(function(){});
  else copyText(u, 'Link copiado');
}

document.addEventListener('click', function(e){
  var b = e.target.closest('[data-act]'); if (!b) return;
  var a = b.dataset.act, id = b.dataset.id;
  switch (a) {
    case 'tab': go(b.dataset.v); break;
    case 'skin': P.skin = b.dataset.v; applyTheme(); savePrefs(); document.querySelectorAll('.skin').forEach(function(x){ x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); break;
    case 'seg':
      var sg = b.closest('.seg');
      sg.style.setProperty('--i', b.dataset.i);
      sg.querySelectorAll('button').forEach(function(x){ x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
      onSeg(b.dataset.seg, b.dataset.v); break;
    case 'cat':
      F.cat = b.dataset.v;
      A('#cats').querySelectorAll('.chip').forEach(function(x){ x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
      A('#list').innerHTML = vendaList(); break;
    case 'close-sheet': closeSheet(); break;
    case 'cart-add':
      var p0 = Pr(id); if (!p0) break;
      var q0 = cart[id] || 0;
      if (q0 >= p0.qty) { toast('Sem mais estoque de ' + p0.name); break; }
      cart[id] = q0 + 1; bump(id); cartbar(); break;
    case 'cart-open': cur = { t: 'cart' }; renderSheet(); break;
    case 'cart-inc': var p = Pr(id); if (p && (cart[id] || 0) < p.qty) cart[id] = (cart[id] || 0) + 1; else toast('Sem mais estoque'); refreshAll(); break;
    case 'cart-dec':
      if ((cart[id] || 0) <= 1) removeLine(id, function(){ delete cart[id]; refreshAll(); });
      else { cart[id]--; refreshAll(); }
      break;
    case 'cart-clear': cart = {}; closeSheet(); render(); break;
    case 'cart-done': finishSale(); break;
    case 'c-new': cur = { t: 'cnew' }; renderSheet(); break;
    case 'c-create': createCom(); break;
    case 'c-open': cur = { t: 'com', id: id, mode: 'view' }; renderSheet(); break;
    case 'c-pick': cur.mode = 'pick'; F.qp = ''; renderSheet(); break;
    case 'c-back': cur.mode = 'view'; renderSheet(); break;
    case 'c-add': case 'c-inc': act({ t: 'com.add', cid: cur.id, pid: id }); break;
    case 'c-dec':
      var cc = comById(cur.id), li = cc && cc.items.filter(function(x){ return x.pid === id; })[0];
      if (li && li.q <= 1) removeLine(id, function(){ act({ t: 'com.remove', cid: cur.id, pid: id }); });
      else act({ t: 'com.dec', cid: cur.id, pid: id });
      break;
    case 'c-rm': removeLine(id, function(){ act({ t: 'com.remove', cid: cur.id, pid: id }, function(){ toast('Item removido'); }); }); break;
    case 'c-close': closeCom(); break;
    case 'c-cancel': confirmAct('c-cancel', b, function(){ var cid = cur.id; act({ t: 'com.cancel', cid: cid }, function(){ closeSheet(); toast('Comanda cancelada'); }); }); break;
    case 'p-new': cur = { t: 'prod', id: 0 }; renderSheet(); break;
    case 'p-open': cur = { t: 'prod', id: id }; renderSheet(); break;
    case 'low-go': closeSheet(); F.low = true; go('estoque'); break;
    case 'photo': cur = { t: 'photo', id: id, prev: cur }; renderSheet(); break;
    case 'ph-rm': stashDraft(); cur.pend = ''; renderSheet(); break;
    case 'p-plus': var f = $('#f-qty'); f.value = (parseInt(f.value, 10) || 0) + (+b.dataset.n); break;
    case 'p-save': saveProd(); break;
    case 'p-del': confirmAct('p-del', b, function(){ var pid = cur.id; delete cart[pid]; act({ t: 'product.delete', pid: pid }, function(){ if (M.mode === 'lan') api('/api/photo?id=' + encodeURIComponent(pid), { method: 'DELETE' }).catch(function(){}); closeSheet(); toast('Produto excluído'); }); }); break;
    case 'sale-open': cur = { t: 'sale', id: id }; renderSheet(); break;
    case 'sale-refund': confirmAct('sale-refund', b, function(){ act({ t: 'sale.refund', sid: cur.id }, function(){ closeSheet(); toast('Venda estornada'); }); }); break;
    case 'prof-edit': cur = { t: 'prof' }; renderSheet(); break;
    case 'prof-save': saveProf(); break;
    case 'bk-copy': copyText(backupText(), 'Backup copiado'); break;
    case 'bk-open': cur = { t: 'bk-in' }; renderSheet(); break;
    case 'bk-restore': confirmAct('bk-restore', b, restore); break;
    case 'reset': cur = { t: 'pw' }; renderSheet(); break;
    case 'pw-ok': confirmReset(); break;
    case 'prune': confirmAct('prune', b, function(){ act({ t: 'sales.prune', before: Date.now() - 120 * 864e5 }, function(r){ toast(r.n + (r.n === 1 ? ' venda antiga removida' : ' vendas antigas removidas')); }); }); break;
    case 'rm-ex': confirmAct('rm-ex', b, function(){ act({ t: 'product.rmex' }, function(){ cart = {}; toast('Exemplos removidos'); }); }); break;
    case 'dev-open':
      cur = { t: 'dev' }; renderSheet();
      if (M.mode === 'lan' && M.host) { pollInfo(); if (!M.inv || M.inv.exp < Date.now()) newInvite('staff', true); }
      break;
    case 'ip-pick': M.ipSel = +b.dataset.i; renderSheet(); break;
    case 'inv-copy': copyText(inviteUrl(), 'Link copiado'); break;
    case 'inv-share': shareInvite(); break;
    case 'inv-regen': confirmAct('inv-regen', b, function(){ newInvite(M.inv ? M.inv.role : 'staff', true).then(function(){ toast('Novo convite gerado. O QR antigo não vale mais.'); }); }); break;
    case 'm-del': confirmAct('m-del-' + id, b, function(){
      api('/api/members/' + encodeURIComponent(id), { method: 'DELETE' }).then(function(){ toast('Celular removido.'); }, function(){ toast('Não consegui remover.'); });
    }); break;
    case 'leave': confirmAct('leave', b, function(){
      try { localStorage.removeItem(TOKKEY); } catch (e) {}
      M.gen++; M.ready = false; M.token = ''; cur = null; renderSheet(); $('#cartbar').hidden = true;
      gate('needinvite', { msg: 'Você saiu da adega neste celular. Para voltar, escaneie o QR code de novo.' });
    }); break;
    case 'g-join': doJoin(); break;
    case 'upd-go': applyUpdate(); break;
    case 'upd-save':
      api('/api/update/config', { method: 'POST', body: ($('#upd-repo').value || '').trim() }).then(function(r){
        if (r.j && r.j.ok) { toast('Endereço salvo'); checkUpdate(true); } else toast('Endereço inválido. Use usuario/repositorio.');
      }, function(){ toast('Não consegui salvar.'); }); break;
    case 'upd-check': checkUpdate(true); break;
  }
});
document.addEventListener('input', function(e){
  var t = e.target;
  if (t.id === 'q') { F.q = t.value; var l = A('#list'); if (l) l.innerHTML = view === 'venda' ? vendaList() : estoqueList(); }
  else if (t.id === 'qp') { F.qp = t.value; var pl = $('#plist'); if (pl) pl.innerHTML = pickList(); }
});
document.addEventListener('change', function(e){
  var t = e.target;
  if (t.id !== 'ph-cam' && t.id !== 'ph-gal') return;
  var f = t.files && t.files[0]; if (!f || !cur || cur.t !== 'prod') return;
  toast('Preparando foto…');
  fileToJpeg(f).then(function(u){ if (!cur || cur.t !== 'prod') return; stashDraft(); cur.pend = u; renderSheet(); }, function(){ toast('Não consegui ler essa foto.'); });
});
document.addEventListener('keydown', function(e){
  if (e.key === 'Enter' && e.target.id === 'cname') { e.preventDefault(); createCom(); }
  if (e.key === 'Enter' && e.target.id === 'g-user') { e.preventDefault(); doJoin(); }
  if (e.key === 'Enter' && e.target.id === 'pw-in') { e.preventDefault(); confirmReset(); }
  if (e.key === 'Escape' && cur) closeSheet();
});
document.addEventListener('visibilitychange', function(){
  if (!document.hidden && M.mode === 'lan' && M.ready) { startSync(); if (M.host && Date.now() - M.updAt > 3600000 && !cur) checkUpdate(false); }
});

/* =====================================================================
   INÍCIO
   ===================================================================== */
/* --- tela de boas-vindas: aparece uma vez a cada abertura do app --- */
var helloShown = false;
function hello(){
  if (helloShown) return; helloShown = true;
  var el = document.createElement('div'); el.id = 'hello'; el.setAttribute('role', 'status');
  el.innerHTML = '<div class="h-logo">' + LOGO + '</div><h2>Bem-vindo, ' + esc(userName()) + '!</h2><p>' + esc(adegaName()) + '</p><small>Toque para entrar</small>';
  document.body.appendChild(el);
  var done = false, t = 0;
  function close(){
    if (done) return; done = true; clearTimeout(t);
    if (animOn()) { el.classList.add('out'); setTimeout(function(){ if (el.parentNode) el.parentNode.removeChild(el); }, 500); }
    else if (el.parentNode) el.parentNode.removeChild(el);
  }
  el.addEventListener('click', close);
  t = setTimeout(close, 2800);
}

function ready(){
  M.ready = true; setSyncUI();
  buildShell(); applyChat(); render(); hello();
  setTimeout(lowAlert, 3300);
}
function startLan(){
  M.mode = 'lan'; M.online = true;
  api('/api/sync?since=-1&wait=0&epoch=').then(function(r){
    if (r.status === 401) { revoked(); return; }
    if (!r.j || !r.j.ops) throw new Error('bad');
    applySync(r.j); startSync();
    var chain = Promise.resolve();
    if (M.host && !member('host')) chain = dispatch({ t: 'member.join', name: 'Mateus' });
    if (M.host) chain = chain.then(function(){ if (!S.seeded && !S.products.length) return dispatch({ t: 'product.seed' }); });
    return chain.then(function(){
      if (!M.host && !member(M.id)) { revoked(); return; }
      ready();
      if (M.host) { setInterval(pollInfo, 10000); setTimeout(function(){ if (!cur) checkUpdate(false); else M.updAt = 0; }, 4000); }
    });
  }).catch(function(){
    gate('needinvite', { msg: 'Não consegui falar com o celular da adega. Confira se está no mesmo Wi-Fi e abra o QR de novo.' });
  });
}
function startLocal(){
  M.mode = 'local'; M.host = true; M.role = 'admin'; M.id = 'host';
  S = loadLocal(); saveLocal(); ready();
}
function boot(){
  applyTheme(); applyAnim();
  S = emptyState();
  var isHttp = /^https?:$/.test(location.protocol);
  if (!isHttp) { startLocal(); return; }
  try { M.token = localStorage.getItem(TOKKEY) || ''; } catch (e) { M.token = ''; }
  api('/api/info', { timeout: 1800 }).then(function(r){
    if (!(r.j && r.j.egua === 1)) { startLocal(); return; }
    M.host = !!r.j.host; M.ips = r.j.ips || []; M.port = r.j.port || +location.port || 8787; M.peers = r.j.peers || {};
    var m = /[?&]j=([A-Za-z0-9]+)/.exec(location.search); JOINCODE = m ? m[1] : '';
    if (M.host) { M.role = 'admin'; M.id = 'host'; startLan(); return; }
    if (r.j.role) { M.role = r.j.role; M.id = r.j.id; if (JOINCODE) { try { history.replaceState(null, '', location.pathname); } catch (e) {} } startLan(); return; }
    M.token = '';
    if (JOINCODE) gate('join'); else gate('needinvite');
  }, function(){ startLocal(); });
}
window.EguaApp = { S: function(){ return S; }, M: function(){ return M; }, dispatch: dispatch, refresh: refreshAll, uid: uid, money: money, errMsg: errMsg, isAdmin: isAdmin, userName: userName, chatOff: function(){ return P.chat === 'off'; }, ready: function(){ return !!(M.ready && S); } };
boot();

})();
