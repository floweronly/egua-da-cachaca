package br.com.eguadacachaca.app;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Servidor HTTP minúsculo (Java puro, sem bibliotecas) que roda DENTRO do celular.
 * Ele não entende as regras da adega: só guarda, em ordem, uma lista de "operações"
 * (cada uma é um texto JSON opaco) e entrega essa lista a quem pedir.
 * Quem calcula estoque, vendas etc. é o JavaScript do app (igual em todos os aparelhos).
 */
public class EguaServer {

    public interface AssetSource { InputStream open(String path) throws IOException; }

    static final int MAX_BODY = 64 * 1024;
    static final int MAX_PHOTO = 400 * 1024;
    static final int MAX_SNAP = 8 * 1024 * 1024;
    static final int MAX_OPS_PER_SYNC = 400;
    static final int MAX_CONN = 80;
    static final long INVITE_MS = 24L * 3600 * 1000;
    static final String ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    private static class Op { long seq, ts; String id, m, r, json; }
    private static class Member { String id, token, role; }
    private static class Invite { String role; long exp; }

    private final File dir;
    private final AssetSource assets;
    private final EguaUpdater up;
    private final int port;
    private final SecureRandom rnd = new SecureRandom();
    private final Object L = new Object();

    private ServerSocket ss;
    private ExecutorService pool;
    private volatile boolean running;
    private final AtomicInteger conns = new AtomicInteger();

    private String epoch = "";
    private long seq = 0, snapSeq = 0;
    private String snapshot = null;
    private final ArrayList<Op> ops = new ArrayList<Op>();
    private final HashMap<String, Long> opIds = new HashMap<String, Long>();
    private final HashMap<String, Member> byToken = new HashMap<String, Member>();
    private final HashMap<String, Member> byId = new HashMap<String, Member>();
    private final HashMap<String, Invite> invites = new HashMap<String, Invite>();
    private final HashMap<String, Long> seen = new HashMap<String, Long>();
    private OutputStream log;
    private long failStart = 0;
    private int fails = 0;

    private static final Member HOST = new Member();
    static { HOST.id = "host"; HOST.role = "admin"; HOST.token = ""; }

    public EguaServer(File dir, AssetSource assets, int port) {
        this.dir = dir; this.assets = assets; this.port = port;
        dir.mkdirs();
        this.up = new EguaUpdater(dir, assets);
    }

    public int port() { return ss != null ? ss.getLocalPort() : port; }

    /* ------------------------------------------------------------------ ciclo de vida */

    public void start() throws IOException {
        synchronized (L) {
            if (running) return;
            dir.mkdirs();
            load();
        }
        ServerSocket s = new ServerSocket();
        s.setReuseAddress(true);
        s.bind(new InetSocketAddress((InetAddress) null, port));
        ss = s;
        pool = new ThreadPoolExecutor(0, 256, 30, TimeUnit.SECONDS, new SynchronousQueue<Runnable>(), new ThreadFactory() {
            public Thread newThread(Runnable r) { Thread t = new Thread(r, "egua-http"); t.setDaemon(true); return t; }
        });
        running = true;
        Thread acc = new Thread(new Runnable() { public void run() { acceptLoop(); } }, "egua-accept");
        acc.setDaemon(true);
        acc.start();
    }

    public void stop() {
        running = false;
        try { if (ss != null) ss.close(); } catch (IOException e) { }
        if (pool != null) pool.shutdownNow();
        synchronized (L) {
            L.notifyAll();
            try { if (log != null) log.close(); } catch (IOException e) { }
            log = null;
        }
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket c = ss.accept();
                if (conns.get() >= MAX_CONN) {
                    try { send(c.getOutputStream(), 503, "application/json", "{\"ok\":false,\"err\":\"busy\"}".getBytes(StandardCharsets.UTF_8)); c.close(); } catch (Exception e) { }
                    continue;
                }
                conns.incrementAndGet();
                try {
                    pool.execute(new Runnable() { public void run() { try { handle(c); } finally { conns.decrementAndGet(); } } });
                } catch (Exception e) { conns.decrementAndGet(); try { c.close(); } catch (IOException x) { } }
            } catch (IOException e) {
                if (!running) return;
            }
        }
    }

    /* ------------------------------------------------------------------ disco */

    private void load() throws IOException {
        epoch = ""; seq = 0; snapSeq = 0; snapshot = null;
        ops.clear(); opIds.clear(); byToken.clear(); byId.clear();
        File meta = new File(dir, "meta");
        if (meta.exists()) {
            List<String> l = readLines(meta);
            if (l.size() >= 2) { epoch = l.get(0).trim(); try { snapSeq = Long.parseLong(l.get(1).trim()); } catch (NumberFormatException e) { snapSeq = 0; } }
        }
        if (epoch.length() == 0) { epoch = randId(8); snapSeq = 0; writeMeta(); }
        File sf = new File(dir, "snapshot.json");
        if (snapSeq > 0 && sf.exists()) {
            List<String> l = readLines(sf);
            if (l.size() > 0 && l.get(0).startsWith("{")) snapshot = l.get(0); else snapSeq = 0;
        } else if (snapSeq > 0) snapSeq = 0;
        seq = snapSeq;
        File lf = new File(dir, "ops.log");
        if (lf.exists()) {
            for (String line : readLines(lf)) {
                String[] p = line.split("\t", 6);
                if (p.length < 6) continue;
                Op o = new Op();
                try { o.seq = Long.parseLong(p[0]); o.ts = Long.parseLong(p[4]); } catch (NumberFormatException e) { continue; }
                if (o.seq <= snapSeq || o.seq <= seq) continue;
                o.id = p[1]; o.m = p[2]; o.r = p[3]; o.json = p[5];
                if (!o.json.startsWith("{") || !o.json.endsWith("}")) continue;
                ops.add(o); opIds.put(o.id, o.seq); seq = o.seq;
            }
        }
        rewriteLog();
        File mf = new File(dir, "members.tsv");
        if (mf.exists()) {
            for (String line : readLines(mf)) {
                String[] p = line.split("\t");
                if (p.length < 3) continue;
                Member m = new Member(); m.id = p[0]; m.token = p[1]; m.role = p[2];
                byToken.put(m.token, m); byId.put(m.id, m);
            }
        }
    }

    private static List<String> readLines(File f) throws IOException {
        ArrayList<String> out = new ArrayList<String>();
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
        try { String s; while ((s = r.readLine()) != null) out.add(s); } finally { r.close(); }
        return out;
    }

    private static void writeAtomic(File f, String text) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        try { o.write(text.getBytes(StandardCharsets.UTF_8)); o.flush(); o.getFD().sync(); } finally { o.close(); }
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new IOException("rename " + f); }
    }

    private void writeMeta() throws IOException { writeAtomic(new File(dir, "meta"), epoch + "\n" + snapSeq + "\n"); }

    private void saveMembers() throws IOException {
        StringBuilder b = new StringBuilder();
        for (Member m : byId.values()) b.append(m.id).append('\t').append(m.token).append('\t').append(m.role).append('\n');
        writeAtomic(new File(dir, "members.tsv"), b.toString());
    }

    private static String opLine(Op o) {
        return o.seq + "\t" + o.id + "\t" + o.m + "\t" + o.r + "\t" + o.ts + "\t" + o.json + "\n";
    }

    private void rewriteLog() throws IOException {
        if (log != null) { try { log.close(); } catch (IOException e) { } log = null; }
        StringBuilder b = new StringBuilder();
        for (Op o : ops) b.append(opLine(o));
        writeAtomic(new File(dir, "ops.log"), b.toString());
        log = new FileOutputStream(new File(dir, "ops.log"), true);
    }

    private Op append(String id, String m, String r, String json) throws IOException {
        Op o = new Op();
        o.seq = seq + 1; o.id = id; o.m = m; o.r = r; o.json = json; o.ts = System.currentTimeMillis();
        if (log == null) log = new FileOutputStream(new File(dir, "ops.log"), true);
        log.write(opLine(o).getBytes(StandardCharsets.UTF_8));
        log.flush();
        seq = o.seq;
        ops.add(o); opIds.put(id, o.seq);
        L.notifyAll();
        return o;
    }

    /* ------------------------------------------------------------------ utilitários */

    private String randId(int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) b.append("0123456789abcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt(36)));
        return b.toString();
    }

    private String randHex(int bytes) {
        byte[] x = new byte[bytes]; rnd.nextBytes(x);
        StringBuilder b = new StringBuilder();
        for (byte v : x) b.append(String.format("%02x", v & 0xff));
        return b.toString();
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8);
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20 || c == 0x2028 || c == 0x2029 || c == 0x7f) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        b.append('"');
        return b.toString();
    }

    static boolean cleanId(String s) {
        if (s == null || s.length() < 1 || s.length() > 40) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return false;
        }
        return true;
    }

    static String cleanName(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < 40; i++) {
            char c = s.charAt(i);
            if (c < 0x20 || c == 0x7f || c == 0x2028 || c == 0x2029) continue;
            b.append(c);
        }
        String r = b.toString().trim();
        return r.length() == 0 ? "Atendente" : r;
    }

    public static List<String> localIps() {
        ArrayList<String> out = new ArrayList<String>();
        String force = System.getProperty("egua.ips"); // só para testes
        if (force != null && force.length() > 0) { Collections.addAll(out, force.split(",")); return out; }
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> ad = ni.getInetAddresses();
                while (ad.hasMoreElements()) {
                    InetAddress a = ad.nextElement();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) out.add(a.getHostAddress());
                }
            }
        } catch (Exception e) { }
        return out;
    }

    /* ------------------------------------------------------------------ HTTP */

    private static String readLine(InputStream in, int max) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > max) throw new IOException("line too long");
        }
        if (c == -1 && b.size() == 0) return null;
        return new String(b.toByteArray(), StandardCharsets.ISO_8859_1);
    }

    private static String reason(int code) {
        switch (code) {
            case 200: return "OK"; case 204: return "No Content"; case 400: return "Bad Request";
            case 401: return "Unauthorized"; case 403: return "Forbidden"; case 404: return "Not Found";
            case 413: return "Payload Too Large"; case 429: return "Too Many Requests";
            case 503: return "Service Unavailable"; default: return "Error";
        }
    }

    private static void send(OutputStream out, int code, String type, byte[] body) throws IOException {
        String h = "HTTP/1.1 " + code + " " + reason(code) + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length +
                "\r\nCache-Control: " + (type.equals("image/jpeg") ? "public, max-age=31536000, immutable" : "no-cache") + "\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.ISO_8859_1));
        out.write(body);
        out.flush();
    }

    private static void json(OutputStream out, int code, String body) throws IOException {
        send(out, code, "application/json; charset=utf-8", body.getBytes(StandardCharsets.UTF_8));
    }

    private static Map<String, String> parseQuery(String q) {
        HashMap<String, String> m = new HashMap<String, String>();
        if (q == null) return m;
        for (String kv : q.split("&")) {
            if (kv.length() == 0) continue;
            int i = kv.indexOf('=');
            try {
                String k = URLDecoder.decode(i < 0 ? kv : kv.substring(0, i), "UTF-8");
                String v = i < 0 ? "" : URLDecoder.decode(kv.substring(i + 1), "UTF-8");
                m.put(k, v);
            } catch (Exception e) { }
        }
        return m;
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            s.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            String line = readLine(in, 8192);
            if (line == null) return;
            String[] rl = line.split(" ");
            if (rl.length < 2) { json(out, 400, "{\"ok\":false}"); return; }
            String method = rl[0], target = rl[1];
            HashMap<String, String> hd = new HashMap<String, String>();
            int total = 0, n = 0;
            while (true) {
                String h = readLine(in, 8192);
                if (h == null || h.length() == 0) break;
                total += h.length();
                if (++n > 64 || total > 32768) { json(out, 400, "{\"ok\":false}"); return; }
                int i = h.indexOf(':');
                if (i > 0) hd.put(h.substring(0, i).trim().toLowerCase(), h.substring(i + 1).trim());
            }
            byte[] body = new byte[0];
            String cl = hd.get("content-length");
            if (cl != null) {
                int len;
                try { len = Integer.parseInt(cl); } catch (NumberFormatException e) { json(out, 400, "{\"ok\":false}"); return; }
                boolean snap = target.startsWith("/api/snapshot") || target.startsWith("/api/reset");
                if (len < 0 || len > (snap ? MAX_SNAP : target.startsWith("/api/photo") ? MAX_PHOTO : MAX_BODY)) { json(out, 413, "{\"ok\":false,\"err\":\"big\"}"); return; }
                body = new byte[len];
                int got = 0;
                while (got < len) { int r = in.read(body, got, len - got); if (r < 0) throw new IOException("eof"); got += r; }
            }
            String path = target, query = null;
            int qi = target.indexOf('?');
            if (qi >= 0) { path = target.substring(0, qi); query = target.substring(qi + 1); }
            boolean loop = s.getInetAddress().isLoopbackAddress();
            if (path.startsWith("/api/")) api(method, path, parseQuery(query), hd, body, loop, out);
            else if (method.equals("GET") || method.equals("HEAD")) statics(path, out);
            else if (method.equals("OPTIONS")) send(out, 204, "text/plain", new byte[0]);
            else json(out, 404, "{\"ok\":false}");
        } catch (Exception e) {
            // conexão caiu ou pedido inválido: ignora
        } finally {
            try { s.close(); } catch (IOException e) { }
        }
    }

    private static String mime(String p) {
        String x = p.toLowerCase();
        if (x.endsWith(".html")) return "text/html; charset=utf-8";
        if (x.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (x.endsWith(".css")) return "text/css; charset=utf-8";
        if (x.endsWith(".json") || x.endsWith(".webmanifest")) return "application/json; charset=utf-8";
        if (x.endsWith(".svg")) return "image/svg+xml";
        if (x.endsWith(".png")) return "image/png";
        if (x.endsWith(".jpg") || x.endsWith(".jpeg")) return "image/jpeg";
        if (x.endsWith(".woff2")) return "font/woff2";
        if (x.endsWith(".woff")) return "font/woff";
        if (x.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    private void statics(String path, OutputStream out) throws IOException {
        String p = path;
        while (p.startsWith("/")) p = p.substring(1);
        if (p.length() == 0) p = "index.html";
        if (p.indexOf("..") >= 0 || p.indexOf('\\') >= 0 || p.indexOf('\0') >= 0 || p.indexOf('%') >= 0) { json(out, 404, "{\"ok\":false}"); return; }
        if (p.startsWith("photos/")) {
            String nm = p.substring(7);
            if (!nm.endsWith(".jpg") || !cleanId(nm.substring(0, nm.length() - 4))) { json(out, 404, "{\"ok\":false}"); return; }
            File pf = new File(new File(dir, "photos"), nm);
            if (!pf.isFile()) { json(out, 404, "{\"ok\":false}"); return; }
            ByteArrayOutputStream pb = new ByteArrayOutputStream();
            InputStream pi = new FileInputStream(pf);
            try { byte[] buf = new byte[16384]; int r; while ((r = pi.read(buf)) > 0) pb.write(buf, 0, r); } finally { pi.close(); }
            send(out, 200, "image/jpeg", pb.toByteArray());
            return;
        }
        InputStream is;
        try { File ov = up.file(p); is = ov != null ? new FileInputStream(ov) : assets.open(p); } catch (FileNotFoundException e) { json(out, 404, "{\"ok\":false}"); return; }
        catch (IOException e) { json(out, 404, "{\"ok\":false}"); return; }
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        try { byte[] buf = new byte[16384]; int r; while ((r = is.read(buf)) > 0) b.write(buf, 0, r); } finally { is.close(); }
        send(out, 200, mime(p), b.toByteArray());
    }

    /* ------------------------------------------------------------------ API */

    private Member auth(Map<String, String> hd, boolean loop) {
        if (loop) return HOST;
        String a = hd.get("authorization");
        if (a == null || !a.startsWith("Bearer ")) return null;
        synchronized (L) { return byToken.get(a.substring(7).trim()); }
    }

    private static boolean hasBody(byte[] b) { for (byte x : b) if (x == '\n' || x == '\r') return true; return false; }

    private void api(String method, String path, Map<String, String> q, Map<String, String> hd, byte[] body, boolean loop, OutputStream out) throws IOException {
        boolean write = !method.equals("GET");
        if (write && !"1".equals(hd.get("x-egua"))) { json(out, 403, "{\"ok\":false,\"err\":\"header\"}"); return; }

        if (path.equals("/api/info") && method.equals("GET")) {
            Member who = auth(hd, loop);
            StringBuilder b = new StringBuilder();
            synchronized (L) {
                if (who != null) seen.put(who.id, System.currentTimeMillis());
                b.append("{\"egua\":1,\"ver\":").append(up.current()).append(",\"epoch\":").append(esc(epoch)).append(",\"seq\":").append(seq)
                        .append(",\"host\":").append(loop).append(",\"port\":").append(port())
                        .append(",\"role\":").append(esc(who == null ? "" : who.role))
                        .append(",\"id\":").append(esc(who == null ? "" : who.id)).append(",\"ips\":[");
                List<String> ips = localIps();
                for (int i = 0; i < ips.size(); i++) { if (i > 0) b.append(','); b.append(esc(ips.get(i))); }
                b.append(']');
                if (loop) {
                    b.append(",\"peers\":{");
                    boolean first = true;
                    long now = System.currentTimeMillis();
                    for (Map.Entry<String, Long> e : seen.entrySet()) {
                        if (!first) b.append(','); first = false;
                        b.append(esc(e.getKey())).append(':').append((now - e.getValue()) / 1000);
                    }
                    b.append('}');
                }
                b.append('}');
            }
            json(out, 200, b.toString());
            return;
        }

        if (path.equals("/api/join") && method.equals("POST")) {
            String code = q.get("code") == null ? "" : q.get("code").trim().toUpperCase();
            synchronized (L) {
                long now = System.currentTimeMillis();
                if (now - failStart > 60000) { failStart = now; fails = 0; }
                if (fails >= 20) { json(out, 429, "{\"ok\":false,\"err\":\"throttle\"}"); return; }
                Invite inv = invites.get(code);
                if (inv == null || inv.exp < now) { fails++; json(out, 403, "{\"ok\":false,\"err\":\"invite\"}"); return; }
                Member m = new Member();
                do { m.id = "g" + randId(6); } while (byId.containsKey(m.id));
                m.token = randHex(24); m.role = inv.role;
                byId.put(m.id, m); byToken.put(m.token, m);
                saveMembers();
                String name = cleanName(new String(body, StandardCharsets.UTF_8));
                append("j" + randId(10), m.id, m.role, "{\"t\":\"member.join\",\"name\":" + esc(name) + "}");
                seen.put(m.id, now);
                json(out, 200, "{\"ok\":true,\"token\":" + esc(m.token) + ",\"id\":" + esc(m.id) + ",\"role\":" + esc(m.role) + "}");
            }
            return;
        }

        Member who = auth(hd, loop);
        if (who == null) { json(out, 401, "{\"ok\":false,\"err\":\"auth\"}"); return; }

        if (path.equals("/api/op") && method.equals("POST")) {
            String id = q.get("id");
            if (!cleanId(id)) { json(out, 400, "{\"ok\":false,\"err\":\"id\"}"); return; }
            if (hasBody(body)) { json(out, 400, "{\"ok\":false,\"err\":\"newline\"}"); return; }
            String js = new String(body, StandardCharsets.UTF_8).trim();
            if (js.length() < 2 || !js.startsWith("{") || !js.endsWith("}")) { json(out, 400, "{\"ok\":false,\"err\":\"json\"}"); return; }
            if (!loop && js.indexOf("member.remove") >= 0) { json(out, 403, "{\"ok\":false,\"err\":\"role\"}"); return; }
            synchronized (L) {
                seen.put(who.id, System.currentTimeMillis());
                Long ex = opIds.get(id);
                if (ex != null) { json(out, 200, "{\"ok\":true,\"seq\":" + ex + ",\"dup\":true}"); return; }
                Op o = append(id, who.id, who.role, js);
                json(out, 200, "{\"ok\":true,\"seq\":" + o.seq + "}");
            }
            return;
        }

        if (path.equals("/api/sync") && method.equals("GET")) {
            long since = -1, wait = 0;
            try { if (q.get("since") != null) since = Long.parseLong(q.get("since")); } catch (NumberFormatException e) { }
            try { if (q.get("wait") != null) wait = Math.min(25, Math.max(0, Long.parseLong(q.get("wait")))); } catch (NumberFormatException e) { }
            String ep = q.get("epoch") == null ? "" : q.get("epoch");
            String resp;
            synchronized (L) {
                long end = System.currentTimeMillis() + wait * 1000;
                while (true) {
                    seen.put(who.id, System.currentTimeMillis());
                    boolean reset = !ep.equals(epoch) || since < 0 || since > seq || since < snapSeq;
                    if (reset || seq > since || !running) break;
                    long left = end - System.currentTimeMillis();
                    if (left <= 0) break;
                    try { L.wait(left); } catch (InterruptedException e) { break; }
                }
                boolean reset = !ep.equals(epoch) || since < 0 || since > seq || since < snapSeq;
                long from = reset ? snapSeq : since;
                StringBuilder b = new StringBuilder();
                b.append("{\"ver\":").append(up.current()).append(",\"epoch\":").append(esc(epoch)).append(",\"seq\":").append(seq).append(",\"snapSeq\":").append(snapSeq)
                        .append(",\"reset\":").append(reset);
                if (reset && snapshot != null) b.append(",\"snapshot\":").append(esc(snapshot));
                b.append(",\"ops\":[");
                int cnt = 0;
                for (Op o : ops) {
                    if (o.seq <= from) continue;
                    if (cnt >= MAX_OPS_PER_SYNC) break;
                    if (cnt++ > 0) b.append(',');
                    b.append("{\"seq\":").append(o.seq).append(",\"id\":").append(esc(o.id)).append(",\"m\":").append(esc(o.m))
                            .append(",\"r\":").append(esc(o.r)).append(",\"ts\":").append(o.ts).append(",\"op\":").append(esc(o.json)).append('}');
                }
                b.append("]}");
                resp = b.toString();
            }
            json(out, 200, resp);
            return;
        }

        if (path.equals("/api/photo") && (method.equals("POST") || method.equals("DELETE"))) {
            if (!"admin".equals(who.role)) { json(out, 403, "{\"ok\":false,\"err\":\"role\"}"); return; }
            String pid = q.get("id");
            if (!cleanId(pid)) { json(out, 400, "{\"ok\":false,\"err\":\"id\"}"); return; }
            File pd = new File(dir, "photos"); pd.mkdirs();
            File pf = new File(pd, pid + ".jpg");
            if (method.equals("DELETE")) { pf.delete(); json(out, 200, "{\"ok\":true}"); return; }
            if (body.length < 4 || (body[0] & 0xff) != 0xFF || (body[1] & 0xff) != 0xD8) { json(out, 400, "{\"ok\":false,\"err\":\"img\"}"); return; }
            File tmp = new File(pd, pid + ".tmp");
            FileOutputStream fo = new FileOutputStream(tmp);
            try { fo.write(body); fo.flush(); } finally { fo.close(); }
            if (!tmp.renameTo(pf)) { pf.delete(); tmp.renameTo(pf); }
            json(out, 200, "{\"ok\":true}");
            return;
        }

        /* ---- só o próprio celular da adega (loopback) daqui para baixo ---- */
        if (!loop) { json(out, 403, "{\"ok\":false,\"err\":\"role\"}"); return; }

        if (path.equals("/api/snapshot") && method.equals("POST")) {
            long n = -1;
            try { n = Long.parseLong(q.get("seq")); } catch (Exception e) { }
            String js = new String(body, StandardCharsets.UTF_8).trim();
            if (hasBody(body) || !js.startsWith("{") || !js.endsWith("}")) { json(out, 400, "{\"ok\":false,\"err\":\"json\"}"); return; }
            synchronized (L) {
                if (!epoch.equals(q.get("epoch")) || n <= snapSeq || n > seq) { json(out, 200, "{\"ok\":false,\"err\":\"stale\"}"); return; }
                writeAtomic(new File(dir, "snapshot.json"), js + "\n");
                snapshot = js; snapSeq = n;
                writeMeta();
                ArrayList<Op> keep = new ArrayList<Op>();
                for (Op o : ops) { if (o.seq > n) keep.add(o); else opIds.remove(o.id); }
                ops.clear(); ops.addAll(keep);
                rewriteLog();
                json(out, 200, "{\"ok\":true}");
            }
            return;
        }

        if (path.equals("/api/reset") && method.equals("POST")) {
            String js = new String(body, StandardCharsets.UTF_8).trim();
            if (hasBody(body) || !js.startsWith("{") || !js.endsWith("}")) { json(out, 400, "{\"ok\":false,\"err\":\"json\"}"); return; }
            synchronized (L) {
                writeAtomic(new File(dir, "snapshot.json"), js + "\n");
                snapshot = js; snapSeq = seq; epoch = randId(8);
                writeMeta();
                ops.clear(); opIds.clear();
                rewriteLog();
                L.notifyAll();
                json(out, 200, "{\"ok\":true,\"epoch\":" + esc(epoch) + ",\"seq\":" + seq + "}");
            }
            return;
        }

        if (path.equals("/api/invite") && method.equals("POST")) {
            String role = "admin".equals(q.get("role")) ? "admin" : "staff";
            synchronized (L) {
                long now = System.currentTimeMillis();
                StringBuilder c = new StringBuilder();
                for (int i = 0; i < 8; i++) c.append(ALPHA.charAt(rnd.nextInt(ALPHA.length())));
                Invite inv = new Invite(); inv.role = role; inv.exp = now + INVITE_MS;
                invites.put(c.toString(), inv);
                json(out, 200, "{\"ok\":true,\"code\":" + esc(c.toString()) + ",\"role\":" + esc(role) + ",\"exp\":" + inv.exp + "}");
            }
            return;
        }

        if (path.equals("/api/update/check") && method.equals("GET")) { json(out, 200, up.check()); return; }
        if (path.equals("/api/update/apply") && method.equals("POST")) {
            String r = up.apply();
            if (r.startsWith("{\"ok\":true")) synchronized (L) { append("u" + randId(10), "host", "admin", "{\"t\":\"app.update\"}"); } // acorda os outros celulares para recarregarem
            json(out, 200, r);
            return;
        }
        if (path.equals("/api/update/config") && method.equals("POST")) {
            boolean ok = up.setRepo(new String(body, StandardCharsets.UTF_8));
            json(out, ok ? 200 : 400, ok ? "{\"ok\":true}" : "{\"ok\":false,\"err\":\"repo\"}");
            return;
        }

        if (path.equals("/api/invites") && method.equals("DELETE")) {
            synchronized (L) { invites.clear(); }
            json(out, 200, "{\"ok\":true}");
            return;
        }

        if (path.startsWith("/api/members/") && method.equals("DELETE")) {
            String id = path.substring("/api/members/".length());
            if (!cleanId(id) || id.equals("host")) { json(out, 400, "{\"ok\":false,\"err\":\"id\"}"); return; }
            synchronized (L) {
                Member m = byId.remove(id);
                if (m != null) byToken.remove(m.token);
                seen.remove(id);
                saveMembers();
                append("r" + randId(10), "host", "admin", "{\"t\":\"member.remove\",\"id\":" + esc(id) + "}");
            }
            json(out, 200, "{\"ok\":true}");
            return;
        }

        json(out, 404, "{\"ok\":false}");
    }

    /* ------------------------------------------------------------------ teste pela linha de comando */

    public static void main(String[] a) throws Exception {
        if (a.length < 3) { System.out.println("uso: EguaServer <pasta-dados> <pasta-public> <porta>"); return; }
        final File pub = new File(a[1]);
        EguaServer s = new EguaServer(new File(a[0]), new AssetSource() {
            public InputStream open(String p) throws IOException { return new FileInputStream(new File(pub, p)); }
        }, Integer.parseInt(a[2]));
        s.start();
        System.out.println("ok " + s.port());
        Thread.sleep(Long.MAX_VALUE);
    }
}
