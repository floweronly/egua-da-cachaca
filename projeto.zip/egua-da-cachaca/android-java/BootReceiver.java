package br.com.eguadacachaca.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Quando o tablet reinicia, liga o servidor da adega sozinho (sem abrir o app). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) EguaService.launch(context);
    }
}
