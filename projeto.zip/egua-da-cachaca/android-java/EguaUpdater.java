package br.com.eguadacachaca.app;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Atualização do app SEM reinstalar o APK.
 * Baixa o pacote das telas (www.zip) do GitHub Releases do próprio projeto e passa a servir
 * essas telas no lugar das que vieram dentro do APK. Só funciona para mudanças em HTML/CSS/JS.
 * Mudou o código Java (servidor)? Aí precisa de um APK novo: suba o número "api".
 */
public class EguaUpdater {
    /** Versão do "contrato" entre telas e servidor. Telas com api maior exigem APK novo. */
    public static final int API = 1;
    static final int MAX_ZIP = 40 * 1024 * 1024;
    static final Pattern REPO = Pattern.compile("^[A-Za-z0-9_.-]{1,80}/[A-Za-z0-9_.-]{1,100}$");

    private final File dir, www;
    private final EguaServer.AssetSource assets;
    private volatile int ver = 0;

    public EguaUpdater(File dir, EguaServer.AssetSource assets) {
        this.dir = dir; this.assets = assets; this.www = new File(dir, "www");
        int bundled = readVer(assetText());
        int over = www.isDirectory() ? readVer(fileText(new File(www, "version.json"))) : 0;
        if (www.isDirectory() && over <= bundled) { rmrf(www); over = 0; } // APK novo vale mais que a atualização antiga
        ver = Math.max(bundled, over);
    }

    public int current() { return ver; }

    /** Arquivo da versão atualizada, ou null para usar o que está dentro do APK. */
    public File file(String p) {
        if (!www.isDirectory()) return null;
        try {
            File f = new File(www, p);
            String base = www.getCanonicalPath() + File.separator;
            if (f.isFile() && f.getCanonicalPath().startsWith(base)) return f;
        } catch (IOException e) { }
        return null;
    }

    public String repo() {
        String r = fileText(new File(dir, "update.txt")).trim();
        return REPO.matcher(r).matches() ? r : "";
    }

    public boolean setRepo(String r) {
        r = r.trim();
        if (r.length() > 0 && !REPO.matcher(r).matches()) return false;
        try { write(new File(dir, "update.txt"), r.getBytes(StandardCharsets.UTF_8)); } catch (IOException e) { return false; }
        return true;
    }

    private String base(String repo) {
        String o = System.getProperty("egua.updbase"); // só para testes
        if (o != null && o.length() > 0) return o;
        return "https://github.com/" + repo + "/releases/download/apk-atual/";
    }

    public String check() {
        String repo = repo();
        String head = "{\"cur\":" + ver + ",\"repo\":" + EguaServer.esc(repo) + ",";
        if (repo.length() == 0) return head + "\"ok\":false,\"err\":\"noconfig\"}";
        try {
            String t = new String(get(base(repo) + "version.json", 65536), StandardCharsets.UTF_8);
            int latest = readVer(t), api = readInt(t, "api");
            if (latest <= 0) return head + "\"ok\":false,\"err\":\"bad\"}";
            return head + "\"ok\":true,\"latest\":" + latest + ",\"api\":" + api + ",\"new\":" + (latest > ver && api <= API) +
                    ",\"needApk\":" + (api > API) + "}";
        } catch (IOException e) {
            return head + "\"ok\":false,\"err\":\"net\"}";
        }
    }

    public synchronized String apply() {
        String repo = repo();
        if (repo.length() == 0) return "{\"ok\":false,\"err\":\"noconfig\"}";
        File tmp = new File(dir, "www.zip.tmp"), nw = new File(dir, "www.new"), old = new File(dir, "www.old");
        try {
            String t = new String(get(base(repo) + "version.json", 65536), StandardCharsets.UTF_8);
            int latest = readVer(t), api = readInt(t, "api");
            if (latest <= ver) return "{\"ok\":false,\"err\":\"uptodate\"}";
            if (api > API) return "{\"ok\":false,\"err\":\"needapk\"}";
            write(tmp, get(base(repo) + "www.zip", MAX_ZIP));
            rmrf(nw); nw.mkdirs();
            unzip(tmp, nw);
            if (!new File(nw, "index.html").isFile() || !new File(nw, "app.js").isFile() || readVer(fileText(new File(nw, "version.json"))) != latest) {
                rmrf(nw); tmp.delete(); return "{\"ok\":false,\"err\":\"bad\"}";
            }
            rmrf(old);
            if (www.exists() && !www.renameTo(old)) { rmrf(nw); tmp.delete(); return "{\"ok\":false,\"err\":\"disk\"}"; }
            if (!nw.renameTo(www)) { if (old.exists()) old.renameTo(www); tmp.delete(); return "{\"ok\":false,\"err\":\"disk\"}"; }
            rmrf(old); tmp.delete();
            ver = latest;
            return "{\"ok\":true,\"ver\":" + latest + "}";
        } catch (IOException e) {
            rmrf(nw); tmp.delete();
            return "{\"ok\":false,\"err\":\"net\"}";
        }
    }

    /* ---------------- utilitários ---------------- */

    private String assetText() {
        try {
            InputStream is = assets.open("version.json");
            try { return new String(readAll(is, 65536), StandardCharsets.UTF_8); } finally { is.close(); }
        } catch (IOException e) { return ""; }
    }

    private static String fileText(File f) {
        try {
            InputStream is = new FileInputStream(f);
            try { return new String(readAll(is, 65536), StandardCharsets.UTF_8); } finally { is.close(); }
        } catch (IOException e) { return ""; }
    }

    static int readVer(String json) { return readInt(json, "v"); }

    static int readInt(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d{1,9})").matcher(json == null ? "" : json);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    private static byte[] readAll(InputStream is, int max) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384]; int r;
        while ((r = is.read(buf)) > 0) { b.write(buf, 0, r); if (b.size() > max) throw new IOException("big"); }
        return b.toByteArray();
    }

    private static byte[] get(String url, int max) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "egua-da-cachaca");
        try {
            if (c.getResponseCode() != 200) throw new IOException("http " + c.getResponseCode());
            InputStream is = c.getInputStream();
            try { return readAll(is, max); } finally { is.close(); }
        } finally { c.disconnect(); }
    }

    private static void write(File f, byte[] b) throws IOException {
        OutputStream o = new FileOutputStream(f);
        try { o.write(b); o.flush(); } finally { o.close(); }
    }

    private static void unzip(File zip, File to) throws IOException {
        String base = to.getCanonicalPath() + File.separator;
        long total = 0;
        ZipInputStream z = new ZipInputStream(new FileInputStream(zip));
        try {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                File f = new File(to, e.getName());
                String cp = f.getCanonicalPath();
                if (!(cp + File.separator).startsWith(base) && !cp.startsWith(base)) throw new IOException("zip");
                if (e.isDirectory()) { f.mkdirs(); continue; }
                f.getParentFile().mkdirs();
                OutputStream o = new FileOutputStream(f);
                try {
                    byte[] buf = new byte[16384]; int r;
                    while ((r = z.read(buf)) > 0) { total += r; if (total > MAX_ZIP * 2L) throw new IOException("big"); o.write(buf, 0, r); }
                } finally { o.close(); }
            }
        } finally { z.close(); }
    }

    private static void rmrf(File f) {
        if (f == null || !f.exists()) return;
        File[] k = f.listFiles();
        if (k != null) for (File x : k) rmrf(x);
        f.delete();
    }
}
