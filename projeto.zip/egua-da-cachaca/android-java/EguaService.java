package br.com.eguadacachaca.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Servidor da adega em tempo integral. Roda como serviço em primeiro plano (com uma
 * notificação fixa), então continua atendendo os outros celulares mesmo com o app
 * fechado e a tela apagada. Também sobe sozinho quando o tablet reinicia.
 */
public class EguaService extends Service {
    public static final int PORT = 8787;
    static final String CHANNEL = "egua_servidor";
    private static EguaServer server;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    /** Liga o servidor (uma vez só por processo). Devolve true se está no ar. */
    public static synchronized boolean ensureServer(Context ctx) {
        if (server != null) return true;
        try {
            final Context app = ctx.getApplicationContext();
            final AssetManager am = app.getAssets();
            EguaServer s = new EguaServer(new File(app.getFilesDir(), "egua"), new EguaServer.AssetSource() {
                @Override
                public InputStream open(String path) throws IOException {
                    return am.open("public/" + path);
                }
            }, PORT);
            s.start();
            server = s;
            return true;
        } catch (Exception e) {
            server = null;
            return false;
        }
    }

    /** Pede ao Android para manter o servidor vivo em segundo plano. */
    public static void launch(Context ctx) {
        try {
            Intent i = new Intent(ctx, EguaService.class);
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Exception e) {
            // se o Android não deixar agora, o servidor continua valendo enquanto o app estiver aberto
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public int onStartCommand(Intent intent, int flags, int startId) {
        boolean ok = ensureServer(this);
        Notification n = buildNotification(ok);
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, 1 << 30); // FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else startForeground(7, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "egua:servidor");
                wake.setReferenceCounted(false);
                wake.acquire();
            }
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "egua:wifi");
                    wifi.setReferenceCounted(false);
                    wifi.acquire();
                }
            }
        } catch (Exception e) {
            // sem trava de energia o servidor ainda funciona, só pode dormir junto com o tablet
        }
        return START_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Notification buildNotification(boolean ok) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = "Égua da Cachaça";
        String text = ok ? "Servidor da adega ligado" : "Servidor não conseguiu ligar (porta ocupada?)";
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Servidor da adega", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi).setOngoing(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Exception e) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Exception e) { }
        wake = null; wifi = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
