package br.com.eguadacachaca.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.BridgeActivity;

/**
 * Tela principal. O servidor da adega (porta 8787) mora no EguaService, que continua
 * rodando com o app fechado. Aqui só garantimos que ele esteja no ar antes de abrir a tela
 * (que acessa http://127.0.0.1:8787) e pedimos as permissões para ele não ser desligado.
 */
public class MainActivity extends BridgeActivity {
    private static final int REQ_NOTIF = 4711;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        EguaService.ensureServer(this);
        super.onCreate(savedInstanceState);
        EguaService.launch(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            try { requestPermissions(new String[] { "android.permission.POST_NOTIFICATIONS" }, REQ_NOTIF); }
            catch (Exception e) { askBatterySoon(); }
        } else {
            askBatterySoon();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) askBatterySoon();
    }

    /** Pede (uma vez) para o Android não "economizar" o app, senão ele pode parar o servidor. */
    private void askBatterySoon() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() { askBattery(); }
        }, 2500);
    }

    private void askBattery() {
        try {
            if (Build.VERSION.SDK_INT < 23) return;
            SharedPreferences sp = getSharedPreferences("egua", Context.MODE_PRIVATE);
            if (sp.getBoolean("bateria_perguntou", false)) return;
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            sp.edit().putBoolean("bateria_perguntou", true).apply();
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            // sem a isenção o app ainda funciona; dá para ajustar em Configurações > Apps > Bateria
        }
    }
}
