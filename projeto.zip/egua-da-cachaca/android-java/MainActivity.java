package br.com.eguadacachaca.app;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Tela principal. Antes de abrir a tela, liga o servidor da adega dentro do próprio
 * celular (porta 8787). A tela do app abre o endereço http://127.0.0.1:8787, e os
 * outros celulares abrem http://IP-DESTE-CELULAR:8787 pelo Wi-Fi.
 */
public class MainActivity extends BridgeActivity {
    public static final int PORT = 8787;
    private static EguaServer server;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        startServer();
        super.onCreate(savedInstanceState);
        // O servidor só responde enquanto o app está aberto: mantém a tela ligada.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private synchronized void startServer() {
        if (server != null) return;
        try {
            final AssetManager am = getApplicationContext().getAssets();
            EguaServer s = new EguaServer(new File(getFilesDir(), "egua"), new EguaServer.AssetSource() {
                @Override
                public InputStream open(String path) throws IOException {
                    return am.open("public/" + path);
                }
            }, PORT);
            s.start();
            server = s;
        } catch (Exception e) {
            server = null;
        }
    }
}
